#########################################################################
# Copyright (c) 2007 Rutu Mulkar-Mehta University of Southern California#
# 4676 Admiralty Way, Marina del Rey, California, 90292, (310) 448-8432 #
# All Rights Reserved                                                   #
#                                                                       #
# THIS IS UNPUBLISHED PROPRIETARY SOURCE CODE OF Rutu Mulkar-Mehta      #
# The copyright notice above does not evidence any                      #
# actual or intended publication of such source code.                   #
#                                                                       #
# Unauthorized copy or distribution of this file is prohibited.         #
#########################################################################

use strict;
use XML::Twig;
my $twig = new XML::Twig();
if(@ARGV != 2)
{
  print "\nUsage: perl parse2xml.pl <input file> <output file>\n";
  exit(0);
}
open(IN,"$ARGV[0]")||die("Cannot open input parse file.\n");
my @parse = <IN>; close(IN); my $line;
my @sentences;
foreach my $p (@parse)
{
  $p =~ s/[\015\012]//;
  if(($p =~ /\(S1 /)&&($line ne ""))
  {
    $line =~ s/[\015\012]//;
    $line =~ s/\$/S/g;
    $line =~ s/:|;|\?|\.|\,|\!|"|`|'|-//g;
    $line =~ s/\t//g;
    $line =~ s/ +/ /g;
    $line =~ s/\(\, \,\)|\(\. \.\)|\(\: \:\)|\(\)|\( \)//g;
    $line =~ s/-LRB-/LRB/g;
    $line =~ s/-RRB-/RRB/g;
    $line =~ s/\)\(/\) \(/g;
    $line =~ s/\t//g;
    push(@sentences,$line);
    $line="";
  }
  $p =~ s/^ +//g;
  $p =~ s/\t//g;
  $p =~ s/[\015\012]//;
  $line=$line."$p";
}
$line =~ s/:|;|\?|\.|\,|\!|"|`|'|-//g;
$line =~ s/\$/S/g;
$line =~ s/\t//g;
$line =~ s/ +/ /g;
$line =~ s/-LRB-/LRB/g;
$line =~ s/-RRB-/RRB/g;
$line=~ s/\(\, \,\)|\(\. \.\)|\(\: \:\)|\(\)|\( \)//g;
$line =~ s/\)\(/\) \(/g;
$line =~ s/[\015\012]//;
push(@sentences,$line);

#Representing this in the form of an XML tree
my $counter=0;
my %hashrule;
my $last;
my $tmp1 = "tmp-$ARGV[1]";
open(OUT,">$tmp1");
print OUT "<TREEBANK>";
foreach my $line (@sentences)
{
  $line =~ s/\)\(/\) \(/g;
  while($line =~ /\(([^\(\)]+)\)/ )
  {
     my @element = split(/ /,$1);
     my $l = parseBraces($line);
     my $root = $element[0];
     my $value;
     if($#element == 1)
     { $value=$element[$#element]; }
     else
     {
        for(my $e=1;$e<=$#element;$e++)
        {
          if($value eq "") { $value = $element[$e]; }
          else { $value=$value." ".$element[$e]; }
        }
     }
     $counter++;
     my $srch = "(".$root." ".$value.")";
     my $repl = "$root:$counter";
     $srch =~ s/ +/ /g;
     $line =~ s/ +/ /g;
     $line =~ s/ \)/\)/g;
     $line =~ s/\( /\(/g;
     $srch =~ s/([\(\)\\\|\[\{\^\*\+\?\.\@\=])/\\\1/g;
     $repl =~ s/([\(\)\\\|\[\{\^\*\+\?\.\@\=])/\\\1/g;
     $line =~ s/$srch/$repl/;
     if($line =~ /^([A-Z]+[0-9]+):([0-9]+)/)
     {
        my @a = split(/:/,$line);
        print OUT "\n\n<TREE><$a[0] node=\"$counter\" cat=\"$a[0]\">";
        print OUT $hashrule{$last};
        print OUT "</$a[0]>";
        print OUT "</TREE>\n\n";
        #exit(0);
     }
     else
     {
       if($value =~ /:([0-9]+)/)
       {
          my @val = split(/ /,$value);
          my $l;
          foreach my $v (@val)
          {
            if($v =~ /:([0-9]+)/)
            {
              my $vv = $hashrule{$v};
              delete $hashrule{$v};
              $l=$l.$vv;
            }
          }
          $hashrule{$root.":".$counter}="<$root node=\"$counter\" cat=\"$root\">$l</$root>";
          $last =  $root.":".$counter;
        }
        else
        {
          my $tmpline;
          $value =~ tr/A-Z/a-z/;
          if($root =~ /\"|\`|\'/)
          {
            $root ="PUNC"
          }
          $tmpline = "cat=\"$root\" root=\"$value\" lex=\"$value\"";
          my $string = getRoot($root);
          $hashrule{$root.":".$counter}="<$root $tmpline node=\"$counter\">$value</$root>";
          $last =  $root.":".$counter;
      }
    }
  }
}
print OUT "</TREEBANK>";
close OUT;

$twig->parsefile("$tmp1");
$twig->set_pretty_print('indented');
open(OUT,">$ARGV[1]");
$twig->print(\*OUT);
close(OUT);
unlink $tmp1;

sub parseBraces
{
  my($current) = @_;
  my $open = ($current =~ tr/(/(/);
  my $close = ($current =~ tr/)/)/);
  if($open == $close) { return($open); } else { return(0); }
}
