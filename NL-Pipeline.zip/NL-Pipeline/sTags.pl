#!/usr/bin/perl -w
use strict;
if(@ARGV != 2)
{
    print "USAGE: sTags.pl <input file> <output file>";
    exit(0);
}
else
{
    my $s1 = $ARGV[0];
    $s1=~ s/\//\/\//g;
    my $s2 = $ARGV[1];
    $s2=~ s/\//\/\//g;
    open(IN,"$s1");
    open(OUT,">$s2");
    while(my $x = <IN>)
    {
    	if(($x ne "\n")&&($x ne ""))
    	{
        	chomp($x);
          $x =~ s/[^[:ascii:]]//g;
	        my $y = "<s> ".$x." </s>\n";
	        print OUT $y;
          print $y;
      }
    }
  close(OUT);
  close(IN);
}

