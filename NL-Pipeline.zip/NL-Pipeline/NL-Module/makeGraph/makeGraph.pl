use strict;
my $something=1;
if(@ARGV != 2)
{
    print "USAGE: makeGraph.pl <input file> <output file>";
    exit(0);
}
else
{
  my $input = $ARGV[0];
  my $output = $ARGV[1];
  my $line;
  open(IN,$input)||die($!);
  my $counter=1;
  my $outfile = $output.".txt";
  open(OUT,">$outfile");
  print OUT "digraph G {\n";
  print OUT "node [color=lightblue2, style=filled];\n";
  close(OUT);
  while($line=<IN>)
  {

      if($line =~ /^#(.*)/)
      {
        $line = <IN>;
        my $num = $1;
        #chomp($line);
        if($line ne "Unable to process the input.\n")
        {
          my $hnf=$line;
          chomp($hnf);
          markNouns($hnf,$outfile);
          $line = <IN>;
        }
        if($line eq "Unable to process the input.\n")
        {
          while($line ne "Partial output:\n")
          { $line = <IN>; }
          $line = <IN>;
          my $hnf=$line;
          chomp($hnf);
          markNouns($hnf,$outfile);
        }
      }
  }
  open(OUT,">>$outfile");
  print OUT "}";
  close(OUT);
  #my $cmd = "dot -Tjpg out-graph.txt > gr.jpg";
  #system($cmd);
}

sub markNouns
{
  my ($data,$outfile) = @_;
  my @props = split(/\ *&\ */,$data);
  my $i=0;
  open(OUT,">>$outfile");
  my (%nouns,%verbs,%verb,%arguments,%nn,%adj,%final,$ctr);
  $ctr=1;
  foreach my $x (@props)
  {
    $x =~ s/\)|\'//g;
    $x =~ s/\(/:/g;
    print $x."\n";
    if($x =~ /(.*)-(nn):(.*)/)
    {
      my @args = split(/,/,$3);
      my $c=1; $nouns{$args[1]}=$1;
    }
    elsif($x =~ /(.*)-(vb):(.*)/)
    {
      my @args = split(/,/,$3); my $c=1;
      $verbs{$1}{'id'}=$args[0]; $verbs{$1}{'agent'}=$args[1]; $verbs{$1}{'object'}=$args[2];
      $verb{$args[0]}=$1;
    }
    elsif($x =~ /^nn:(.*)/ )
    {
      my @args = split(/,/,$1); $nn{$args[1]}=$args[2];
    }
    elsif($x =~ /(.*):(.*)/ )
    {
      my @args = split(/,/,$2);
      print " ".$1." ";
      if($#args == 2)
      { if(($1 ne "a")&&($1 ne "an")&&($1 ne "the")&&($1 ne "typelt")) { $arguments{$1}{'id'}=$args[0]; $arguments{$1}{'1'}=$args[1]; $arguments{$1}{'2'}=$args[2]; } }
      elsif($#args ==3)
      {
        if($1 eq "andn")
        {
          $arguments{$1}{'id'}=$args[1];
          $arguments{$1}{'1'}=$args[2];
          $arguments{$1}{'2'}=$args[3];
          $nouns{$args[1]}=$1;
        }
      }
    }
   }
   #join the compound nominals and create a superclass for them
   foreach my $n (keys %nn)
   {
     my ($k,$v);
     if(exists $nouns{$n}) { $k = $nouns{$n}; }
     else { $k = $n; }
     if(exists $nouns{$nn{$n}}) { $v = $nouns{$nn{$n}}; }
     else { $v = $nn{$n}; }
     my $str = $k."_".$v;
     #$final{"nouns"}{$nn{$n}}{"name"} = $str;
     $final{"nouns"}{$str}{"of_type"} = $v;
     $nouns{$nn{$n}}=$str;
     $nouns{$n}=$str;
     $nouns{"new".$ctr}=$v;
     $ctr++;
     $final{"class"}{$v}=1;
   }
   #join the verbs with the noun instances
   foreach my $v (keys %verbs)
   {
     my ($a,$o);
     if(exists $nouns{$verbs{$v}{"agent"}})
     {  $a = $nouns{$verbs{$v}{"agent"}};}
     else
     { $a = "something".$something; $something++;}
     if(exists $nouns{$verbs{$v}{"object"}})
     {  $o = $nouns{$verbs{$v}{"object"}};}
     else
     { $o = "something".$something; $something++;}
     $final{"verbs"}{$v}{"agent"} = $a;
     $final{"verbs"}{$v}{"object"} = $o;
   }
   #adding details of all the nouns
   foreach my $n (keys %nouns)
   {
     my ($k);
     $final{"nouns"}{$nouns{$n}}{"id"} = 1;
     $final{"nouns"}{$nouns{$n}}{"id"} = 1;
   }
   #adding details of misc words -- these might be required to abduce over and generalise into
   #classes
   foreach my $m (keys %arguments)
   {
     my %word = %{$arguments{$m}};
     my ($a,$o);
     foreach my $w (keys %word)
     {
        if(($word{$w} =~ /^e[0-9]*/)&&($w ne "id"))
        {
          #check for verbs
          if(exists $verb{$word{$w}})
          {if($w eq "1"){ $a = $verb{$word{$w}};} elsif($w eq "2"){ $o = $verb{$word{$w}}; } }
          else { if($w eq "1"){ $a = "something".$something; $something++;} elsif($w eq "2"){ $o = "something".$something; $something++;} }
        }
        elsif($word{$w} =~ /^x[0-9]*/)
        {
          #check for nouns
          if(exists($nouns{$word{$w}}))
          { if($w eq "1"){ $a = $nouns{$word{$w}};} elsif($w eq "2"){ $o = $nouns{$word{$w}};} print $nouns{$word{$w}}; }
          else { if($w eq "1"){ $a = "something".$something; $something++;} elsif($w eq "2"){ $o = "something".$something; $something++;} }
        }
     }
     $final{"others"}{$a}{$m}=$o;
   }

   #print the final set for graph printing
   foreach my $f (keys %final)
   {
     if($f eq "class")
     {
        #"engine" [shape=box, color=yellow, style=filled]
        my %class = %{$final{$f}};
        foreach my $c (keys %class)
        {
          print OUT "\"$c\" [shape=box, color=yellow, style=filled];\n";
        }
     }
     if($f eq "nouns")
     {
        my %nns = %{$final{$f}};
        foreach my $c (keys %nns)
        {
          my %val = %{$nns{$c}};
          foreach my $x (keys %val)
          {
            if($x ne "id")
            { print OUT "\"$c\" -> \"$val{$x}\" [label=\"$x\"];\n"; }
            else
            { print OUT "\"$c\";\n"; }
          }
        }
     }
     if($f eq "verbs")
     {
        my %vbs = %{$final{$f}};
        foreach my $v (keys %vbs)
        {
          #"gasoline_engine" -> "combustion_engine" [label="subclass_of"];
          #"suck" [shape=diamond, color=green, style="rounded,filled"];
          print OUT "\"$v\" [shape=diamond, color=green, style=\"rounded,filled\"];\n";
          print OUT "\"$final{$f}{$v}{\"agent\"}\" -> \"$v\" [label=\"agent-of\"]\n";
          print OUT "\"$final{$f}{$v}{\"object\"}\" -> \"$v\" [label=\"object-of\"]\n";
        }
     }
     if($f eq "others")
     {
        my %oth = %{$final{$f}};
        foreach my $v (keys %oth)
        {
          #"gasoline_engine" -> "combustion_engine" [label="subclass_of"];
          my %kv = %{$oth{$v}};
          foreach my $kvk (keys %kv)
          {
            if($kvk eq "andn")
            { print OUT "\"$v\" -> \"$kvk\"\n";
              print OUT "\"$kv{$kvk}\" -> \"$kvk\"\n";
            }
            else
            {
              if(($v !~ /something/)&&($kv{$kvk} !~ /something/))
              {
                print OUT "\"$v\" -> \"$kv{$kvk}\" [label=\"$kvk\"]\n";
              }
            }
          }
        }
     }

     
   }
   close(OUT);
  print "\n";
}
