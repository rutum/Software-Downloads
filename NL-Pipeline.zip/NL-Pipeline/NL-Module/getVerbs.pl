#!/usr/bin/perl

use strict;

if($#ARGV != 0 )
{
	print "Usage: perl reorderLogicalForms.pl <input file>\n";
}
else
{
	open (IN,"$ARGV[0]");
  my %verbs;
	while(my $x = <IN>)
	{
		if($x =~ /\w+\'\(.*\)/)
		{
			my %LFTerms;
			chomp($x);
			my $lfLine = $x;
			my @terms = split(" & ",$lfLine);
			my @blanks;
			foreach my $t (@terms)			
			{
				if($t =~ /(.+)-(.+)'\((.+)\)_(.*)/)
        {
          my $pos = $2;
          if($pos eq "vb")
          {
            $verbs{$1}=1;
          }
        }
			}
    }
  }
  close(IN);
  foreach my $v (keys %verbs)
  {
    print $v."\n";
  }
}

