use strict;
if(@ARGV != 3)
{
    print "USAGE: format_for_tacitus.pl <input file> <output file> <cost>";
    exit(0);
}
else
{
  my $counter=1;
  my $input = $ARGV[0];
  my $output = $ARGV[1];
  my $cost = $ARGV[2];
  my $line;

  open(IN,$input);
  while($line=<IN>)
  {
      if($line =~ /^#(.*)/)
      {
        $line = <IN>;
        my $num = $1;
        #chomp($line);
        if($line ne "Unable to process the input.\n")
        {
          my $hnf=$line;
          chomp($hnf);
          my $tacitus_hnf=represent($hnf,$cost,$num);
          my $str = $output."//".$counter.".txt";
          open(OUT,">$str");
          print OUT $num."] ".$tacitus_hnf."| \n";
          close(OUT);
          $line = <IN>;
          $counter++;
        }
        if($line eq "Unable to process the input.\n")
        {
          while($line ne "Partial output:\n")
          {
            $line = <IN>;
          }
          $line = <IN>;
          my $hnf=$line;
          chomp($hnf);
          my $tacitus_hnf=represent($hnf,$cost,$num);
          my $str = $output."//".$counter.".txt";
          open(OUT,">$str")|| die ("cannot open");
          print OUT $num."] ".$tacitus_hnf."| \n";
          close(OUT);
          $counter++;
        }
      }
  }
}

sub represent
{
  my ($data,$cost,$num) = @_;
  my @props = split(/\ *&\ */,$data);
  my @propsBackup;# = @props;;
  my $ret;
  my $NM_ret;
  my $i=0;
  my %pred;
  my %nouns;
  foreach my $x (@props)
  {
    if($x=~ /(.*)\((.*)\)_(.*)/)
    {
      #create a hashtable here with pred name and values
      #If 2 preds have the same name, their args cannot be merged.

      my $currPred = $1;
      my @data = split(/-/,$currPred);
      my $arg = $2;
      my $id = $3; my $argList;
      my @args = split(/,/,$arg);
      foreach my $a (@args)
      {
        $argList = $argList.",".$num.$a;
      }
      $argList=~ s/^,//;
      #chop($argList);
      my $newProp = $currPred."(".$argList.")_".$id;
      push(@propsBackup,$newProp);
      
      if($data[1] eq "nn'")
      {
        $nouns{$currPred}=$argList;
      }
      if(exists $pred{$currPred})
      {
        my $var = $pred{$currPred};
        $var = $var.",".$argList;
        $pred{$currPred}=$var;
      }
      else
      {
        $pred{$currPred}=$argList;
      }
    }
  }
  foreach my $x (keys %pred)
  {
    my $val = $pred{$x};
    my $nm=find_noMerge($val);

    if($NM_ret eq "")
    {
      $NM_ret=$NM_ret.$nm;
    }
    else
    {
      $NM_ret=$NM_ret.",".$nm;
    }
  }
  foreach my $x (@propsBackup)
  {
    $x =~ s/_/:/g;
    $x=$x.":".$cost;
    $ret=$ret.$x.":0:{} & ";
  }
  chop($ret); chop($ret); chop($ret);
  my $nmNouns = nouns_noMerge(%nouns);
  return($ret."|".$NM_ret.$nmNouns);
}

sub find_noMerge
{
  my ($args) = @_;
  my @args = split(/,/,$args);
  my $nm;
  for(my $i=0;$i<=$#args-1;$i++)
  {
    for(my $j=$i+1;$j<=$#args;$j++)
    {
      if($nm eq "")
      {
        $nm=$nm.$args[$i]."-".$args[$j];
      }
      else
      {
        $nm=$nm.",".$args[$i]."-".$args[$j];
      }
    }
  }
  return($nm);
}
sub nouns_noMerge
{
  my (%nouns) = @_;
  my $noMerge;
  my @keys = keys(%nouns);
  for(my $i=0;$i<=$#keys;$i++)
  {
    for(my $ii=$i+1;$ii<=$#keys;$ii++)
    {
      my @data1 = split(/,/,$nouns{$keys[$i]});
      my @data2 = split(/,/,$nouns{$keys[$ii]});

      $noMerge = $noMerge.",".$data1[0]."-".$data2[0];
      $noMerge = $noMerge.",".$data1[1]."-".$data2[1];
      #print "here";
    }
  }
  return($noMerge);
}

