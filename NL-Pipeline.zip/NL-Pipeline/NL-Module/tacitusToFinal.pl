use strict;
if(@ARGV != 2)
{
    print "USAGE: tacitusToFinal.pl <input file> <output file>";
    exit(0);
}
my $input = $ARGV[0];
my $output = $ARGV[1];
open(IN,"$input");
my $line;
my (@lf,@final,@finalDat,@status,%args);

my $outtxt=$output.".txt";
my $outhtm=$output.".htm";
open(OUT,">$outtxt");
close(OUT);
open(OUT,">$outhtm");
close(OUT);

my @entiredata = <IN>;
my $i=0;
my $counter=1;
if($#entiredata ==-1)
{
  push(@status,"MT: Failure");
}
  my $success="0";
while($i <$#entiredata)
{
  @final=();
  @finalDat=();
  @lf=();
  $line = $entiredata[$i];
  while(($line !~/^------------------/))
  {

    #$line = <IN>;
    chomp($line);
    push(@lf,$line);
    $i++;
    if($i > $#entiredata)
    {
      exit;
    }
    $line = $entiredata[$i];


  }
  if($line !~/^----------------/)
  {
    exit;
  }


  foreach my $x (@lf)
  {
    $success="1";
    if(($x !~/^----------------------/) && ($x ne ""))
    {
      $x=~ s/\)//g;
      $x=~ s/\(/:/g;
      if($x =~ /Interpt Number:|Cost:|Axiom:/)
      {
        my @d = split(/:/,$x);
        my $a,$b;
        if($d[0] =~ /Interpt Number/)
        {
           $d[1]=$counter;
           $counter++;
           $finalDat[0]=$d[0]." ".$d[1];
        }
        elsif($d[0] =~ /Cost/)
        {
           $d[1]="0.1";
           $finalDat[1]=$d[0]." ".$d[1];
        }
      }
      else
      {
        $x =~ s/ //g;
        $x =~ s/:/ /g;
        $x =~ s/,/ /g;

        my @data = split(/ /,$x);
        $data[0]=~ s/'//g;
        my @pos = split(/-/,$data[0]);
        $pos[0] =~ s/([0-9]*)//g;
        $pos[0] =~ s/_/-/g;
        if(($#pos == 1) && ($pos[1] eq "nn"))
        {
          if(exists $args{$data[2]})
          {
            push(@status,"MT: Multiple noun argument instances: ".$data[2]);
          }
          else
          {
             $args{$data[2]}=$data[2]."-".$pos[0];
          }
          my $tmp1 = $args{$data[2]}." instance-of ".$pos[0];
          push(@final,$tmp1);
          $tmp1 = $pos[0]." pos noun";
          push(@final,$tmp1);
        }
        elsif(($pos[1] eq "vb"))
        {
          if($#data < 3)
          {
            if(exists $args{$data[1]})
            {
              push(@status,"MT: Multiple verb argument instances");
            }
            else
            {
               $args{$data[1]}=$data[1]."-".$pos[0];
            }
            my $tmp1 = $args{$data[1]}." instance-of ".$pos[0];
            push(@final,$tmp1);
            $tmp1 = $pos[0]." pos verb";
            push(@final,$tmp1);

          }
          else
          {
            if(exists $args{$data[1]})
            {
              push(@status,"MT: Multiple verb argument instances");
            }
            else
            {
               $args{$data[1]}=$data[1]."-".$pos[0];
            }
            my $tmp1 = $args{$data[1]}." instance-of ".$pos[0];
            push(@final,$tmp1);
            
            $tmp1 = $data[2]." ".$pos[0]." ". $data[3];
            push(@final,$tmp1);
            $tmp1 = $pos[0]." pos verb";
            push(@final,$tmp1);
            $tmp1 = $data[2]." agent-of ".$args{$data[1]};
            push(@final,$tmp1);
            $tmp1 = $data[3]." object-of ".$args{$data[1]};
            push(@final,$tmp1);
            $tmp1 = $pos[0]." pos verb";
            push(@final,$tmp1);
            push(@status,"MT: New Verb-\'".$pos[0]."'");
          }
        }
        elsif($pos[1] eq "adj")
        {
          if($#data == 2)
          {
            my $tmp1 = $data[2]." MOD ". $pos[0];
            push(@final,$tmp1);
            $tmp1 = $pos[0]." pos adj";
            push(@final,$tmp1);
          }
          else
          {
            my $tmp1 = $data[2]." ".$pos[0]." ". $data[3];
            push(@final,$tmp1);
            $tmp1 = $pos[0]." pos adj";
            push(@final,$tmp1);
            
          }
        }
        elsif($pos[1] eq "tense")
        {
          if($#data == 2)
          {
            my $tmp1 = $data[2]." tense ". $pos[0];
            push(@final,$tmp1);
          }
        }
        else
        {
          if($pos[1] eq "CARD")
          {
            my $tmp1 = $data[2]." cardinality ". $pos[0];
            push(@final,$tmp1);
          }

          elsif($pos[0]=~/quest/)
          {
            my $tmp1 = $pos[0]." ( ". $data[2].",". $data[3]." )";
            push(@final,$tmp1);
          }
          elsif($pos[0] eq "typelt")
          {
            my $tmp1 = $data[3]." plural ". $data[2];
            push(@final,$tmp1);
          }
          elsif($pos[0]=~/-of/)
          {
            my $tmp1 = $data[2]." ".$pos[0]." ". $data[3];
            push(@final,$tmp1);
          }
          else
          {
            if(($pos[0] eq "andn")||($pos[0] eq "orn"))
            {
              if(exists $args{$data[1]})
              {
                push(@status,"MT: Multiple argument instances");
              }
              else
              {
                $args{$data[1]}=$data[1]."-".$pos[0];
              }
              my $tmp1 = $args{$data[1]}." eventuality-of ".$pos[0];
              push(@final,$tmp1);
              $tmp1 = $data[2]." agent-of ".$pos[0];
              push(@final,$tmp1);
              $tmp1 = $data[2]." ".$pos[0]." ".$data[3];
              push(@final,$tmp1);
              $tmp1 = $data[2]." ".$pos[0]." ".$data[4];
              push(@final,$tmp1);
            }
            elsif($#data != 2)
            {
              if(exists $args{$data[1]})
              {
                push(@status,"MT: Multiple argument instances");
              }
              else
              {
                $args{$data[1]}=$data[1]."-".$pos[0];
              }
              my $tmp1 = $args{$data[1]}." eventuality-of ".$pos[0];
              push(@final,$tmp1);
              my $tmp1 = $data[2]." ".$pos[0]." ". $data[3];
              push(@final,$tmp1);
            }
            else
            {
              if(exists $args{$data[1]})
              {
                push(@status,"MT: Multiple argument instances");
              }
              else
              {
                $args{$data[1]}=$data[1]."-".$pos[0];
              }
              my $tmp1 = $args{$data[1]}." eventuality-of ".$pos[0];
              push(@final,$tmp1);
              my $tmp1 = $data[2]." instance-of ". $pos[0];
              push(@final,$tmp1);
            }
          }
        }
      }
    }
  }

}

if($success eq "1")
{
  push(@status,"MT: Successful");
}
  my @final1;
  foreach my $y (@final)
  {
    my @data = split(/ /,$y);
    if(exists $args{$data[0]})
    {
      $data[0]=$args{$data[0]};
    }
    if(exists $args{$data[2]})
    {
      $data[2]=$args{$data[2]};
    }
    my $r = $data[0]." ".$data[1]." ".$data[2];
    push(@final1,$r);
  }
  

  open(OUT,">>$outtxt");
  print OUT "(";
  foreach my $y (@final1)
  {
    print OUT "( ".$y . " )\n";
  }
  print OUT ")\n";
  foreach my $y (@finalDat)
  {
     print OUT $y ."\n";
  }
  print OUT "((success ()))\n";
  print OUT "()\n";

  print OUT "---------------------------------\n\n";
  close(OUT);

  #open (S,"s1.txt");
  #my @s = <S>;
  #close(S);
  open(OUT,">>$outhtm");
  print OUT "<HTML><HEAD></HEAD>";
  #print OUT "<BODY><H2>CURRENT SENTENCE</H2>";
  #print OUT $s[0];
  print OUT "<H2>OUTPUT TRIPLES</H2>\n<TRIPLES>";
  foreach my $y (@finalDat)
  {
     print OUT $y ."<BR>";
  }
  print OUT "<OL>";
  foreach my $y (@final1)
  {
     print OUT "<LI>".$y ;
  }
  print OUT "</OL>---------------------------------<BR><BR>";
  open(INCIDENT, ">Incident.txt");
  print OUT "</TRIPLES>\n<H2>INCIDENTS</H2><INCIDENTS>";

  print OUT "<b>Parse incidents:</b><br>";
  print INCIDENT "Parsing incidents:\n\n";
  if(-e "intStatusParse.txt")
  {
    open(INT,"intStatusParse.txt");
    while(my $r=<INT>)
    {
      print OUT $r."\n";
      print INCIDENT $r."\n";
    }
  }
  else
  {
    print OUT "NIL<br>";
    print INCIDENT "NIL:\n\n";
  }
  print OUT "<br><b>Intermediate Logical Form incidents:</b><br>";
  print INCIDENT "Intermediate Logical Form incidents:\n\n";
  open(INT,"intStatusLF.txt");
  while(my $r=<INT>)
  {
    print OUT $r."\n";
    print INCIDENT $r."\n";
  }
  close(INT);
  print OUT "<br><br><b>Final Triplet incidents:</b><br>";
  print INCIDENT "\nFinal Triplet incidents:\n\n";
  if($#status==-1)
  {

  }
  else
  {
    foreach my $x(@status)
    {
      print OUT $x."<br>\n";
      print INCIDENT $x."\n";
    }
  }
  print OUT "</INCIDENTS>";
  print OUT "</BODY>";
  print OUT "</HTML>";
  close(OUT);
  $i++;
  $line = $entiredata[$i];
  print $line;

