use strict;
use XML::Twig;
my $twig = new XML::Twig(twig_handlers =>{
	     S => \&subAll,
	     S1 => \&subAll,
      CLAUSE => \&subAll,
      	     SQ => \&subAll,
      	     SBAR => \&subAll,
      	     SBARQ => \&subAll,
             VP => \&subAll,
             VB => \&subAll,
             VBZ => \&subAll,
             VBP => \&subAll,
             VBD => \&subAll,
             VBG => \&subAll,
             VBN => \&subAll,
             VERB => \&subAll,
             VSTEM => \&subAll,
             AUX => \&subAll,
             AUXG => \&subAll,
             MD => \&subAll,
             NP => \&subAll,
             WHNP => \&subAll,
             DETP => \&subAll,
             QP => \&subAll,
             CDP => \&subAll,
             PP => \&subAll,
             ADJP => \&subAll,
             WHADVP => \&subAll,
	           ADVP => \&subAll,
             NPA => \&subAll,
             CONJP => \&subAll,
             RB => \&subAll,
             WP => \&subAll,
             WRB => \&subAll,
             PRT => \&subAll,
             RP => \&subAll,
             PRP => \&subAll,
             PDT => \&subAll,
             PRPD => \&subAll,
             POS => \&subAll,
             CD => \&subAll,
             JJR => \&subAll,
             JJS => \&subAll,
             NN => \&subAll,
             NNS => \&subAll,
             NNP => \&subAll,
             CC => \&subAll,
             RBR => \&subAll,
             RBS => \&subAll,
             PRN => \&subAll,
             NBAR => \&subAll,
             NPONE => \&subAll,
      	     SINV => \&subAll});

if(@ARGV != 3)
{
  print "\nUsage: perl tree_transformer_new.pl <rules file> <input xml file> <output xml file>\n";
  exit(0);
}

#Read the file, store each rule structure antecedent and Consequent
open(IN,"$ARGV[0]") || die ("Cannot open Transformation rules file");
my (%ruleset,$index,@ret_value,%propagate,$atr_counter,%in_system);
$index=0;
$atr_counter=0;
while(my $rule = <IN>)
{
  my (%hashrule,$str_ant,$str_cons,$org_num);
  chomp($rule);
  #print "RULE: ".$rule;
  #check for rule validity, and split into Ant, conse and org_num if valid
  #if invalid, print message and exit
  if(($rule=~/([0-9]*)\] (\(.*\)) => (\(.*\))/)&&($rule!~ /^\/\//))
  {
    $org_num = $1; $str_ant = $2; $str_cons = $3;
    if(parseBraces($str_ant)==-1){print "Unmatched braces in antecedent Line: ". $org_num; system.exit(0);}
    if(parseBraces($str_cons)==-1){ print "Unmatched braces in antecedent Line: ". $org_num; system.exit(0); }

    #Parse the Antecedent into its valid structure
    my %antecedent = makeStructure($str_ant,"antecedent");
    my %consequent = makeStructure($str_cons,"consequent");
    $hashrule{'antecedent'}={ %antecedent };
    $hashrule{'consequent'}={ %consequent };
    $hashrule{'org_num'}=$org_num;
    $ruleset{$index}={ %hashrule };
    $index++;
  }
  elsif(($rule !~ /^\/\//)&&($rule ne ""))
  { print "Possible Incorrect Format ".$rule; system.exit(0); }
}
close(IN);
my $change=1;

#Check if input file exists
open(TEST,"$ARGV[1]") || die "$ARGV[1] does not exist!!! ";
close(TEST);
open(TRACE,">trace.txt");

#parse the input text file
$twig->parsefile("$ARGV[1]");

#Print the updated parse to misc.xml
open(OUT,">misc.xml") or die "cannot open out file out_file:$!";
$twig->print(\*OUT);
close(OUT);
my $fname="misc";

print "misc.xml written\n";
$change=1;
#print %in_system;
while($change==1)
{
  $change=0;
  if($fname eq "misc")
  {
    $twig->parsefile("misc.xml");
    open( OUT, ">misc2.xml") or die "cannot open out file out_file:$!";
    $twig->print(\*OUT);
    close(OUT);
    $fname="misc2";
    print "misc2.xml written\n";
    #print %in_system;
  }
  elsif($fname eq "misc2")
  {
    $twig->parsefile("misc2.xml");
    open( OUT, ">misc.xml") or die "cannot open out file out_file:$!";
    $twig->set_pretty_print( 'indented');
    #$twig->print;
    $twig->print(\*OUT);
    close(OUT);
    print "misc.xml written\n";
    $fname="misc";
    #print %in_system;
  }
}
$change="done1";
%propagate=();
#loop to keep parsing the files misc and misc2 if change=1
if($fname eq "misc")
{
print "Parsing misc.xml";
  $twig->parsefile("misc.xml");
  print "done parsing misc.xml";
  open(OUT,">misc2.xml");
  $twig->set_pretty_print( 'indented');
  $twig->print(\*OUT);
  close(OUT);
#print "PROPAGATE:".%propagate."\n";
  foreach my $p (keys %propagate)
   {
       #print "propagate key:".$p."\n";
     my %inside = %{$propagate{$p}};
#print "INSIDE:".%inside."\n";
     foreach my $k (keys %inside)
     {
       #print "inside  p=>$p with  key=>$k\n";
       if($propagate{$p}{$k} =~ /n(\d+)/)
       {
         my $tmp = $propagate{$p}{$k};
     my %beenThere=();
     my $loopcnt = 0;
         while(($tmp =~ /n(\d+)/)&&
       ($tmp ne $propagate{$tmp}{$k})&&
       (! $beenThere{$tmp}) )
        {  ### added pmartin 4 oct 07
         $beenThere{$tmp} = $loopcnt;
         print "Loopy again   tmp=>".$tmp." with propagate=>".$propagate{$tmp}{$k}."\n";
         if ($loopcnt++ > 30) 
         {
            die ("looped too long \n");
          }
            $tmp=$propagate{$tmp}{$k};
         }
         $propagate{$p}{$k}=$tmp;
       }
     }
   }

  $change="done2";
   print "about to parse misc2.xml";
  $twig->parsefile("misc2.xml");
  open(OUT,">misc.xml");
  $twig->set_pretty_print( 'indented');
  $twig->print(\*OUT);
  close(OUT);

    #print "ok";
  $change="final";
  $twig->parsefile("misc.xml");
}
if($fname eq "misc2")
{
print "parsing misc2.xml";
  $twig->parsefile("misc2.xml");
  open(OUT,">misc.xml");
  $twig->set_pretty_print( 'indented');
  $twig->print(\*OUT);
  close(OUT);
  foreach my $p (keys %propagate)
    {
      print "nother propagate key:".$p."\n";
      my %inside = %{$propagate{$p}};
      foreach my $k (keys %inside)
        {
	    print "nother inside key:".$k."\n";
	    my %beenHere=();
	    my $loop2cnt = 0;
	    my $oldtmp = $propagate{$p}{$k};
	    my $tmp;
	    ### added pmartin 9 oct 07
	    ;
	    while(($beenHere{$oldtmp} = $loop2cnt) &&
		  ($oldtmp =~ /n(\d+)/)&&
		  ($tmp = $propagate{$oldtmp}{$k}) &&	
		  ($oldtmp ne $tmp)  &&
		  (! $beenHere{$tmp}) 
		  )
	    {
		print "nother propagating old tmp:".$oldtmp.": to new tmp:".$tmp.":\n";
		die ("second loop looped too long \n") unless  ($loop2cnt++ < 10) ;
		$propagate{$p}{$k}=$tmp;
		$oldtmp = $tmp;
	    }
	}
     }
  $change="done2";
  $twig->parsefile("misc.xml");
  open(OUT,">misc2.xml");
  $twig->set_pretty_print( 'indented');
  $twig->print(\*OUT);
  close(OUT);

    #print "ok";
  $change="final";
  $twig->parsefile("misc2.xml");
}
open(OUT,">$ARGV[2]");
$twig->set_pretty_print( 'indented');
$twig->print(\*OUT);
close(OUT);
close(TRACE);
unlink "misc.xml";
unlink "misc2.xml";

close(TRACE);
my $fname="misc";


#print "\nCompleted.....\n";

sub subAll
{
  my( $twig, $element)= @_;
  #if($change eq "final")
  #{
  #  print "here";
    #$element->del_att('new_id');
    #$element->del_att('head');
    #$element->del_att('parsed');
  #}
  if($change eq "done1")
  {
    #populate the propagate hash table
    #print "populate the propagate hash table\n";
    if(exists $element->{'att'}->{'new_id'})
    {
      #$element->print();
      my %attributes = %{$element->{'att'}};
      #$element->del_att('new_id');
      $propagate{$element->{'att'}->{'new_id'}} = { %attributes };
    }
  }
  elsif($change eq "done2")
  {
    #if head = n7, get all the attributes from n7 to the current node
    #### pmartin removed 9 oct 07
      #### print "if head = n7, get all the attributes from n7 to the current node\n";
    if(exists $element->{'att'}->{'head'})
    {
      if(exists $propagate{$element->{'att'}->{'head'}})
      {
        my %atrb = %{ $propagate{$element->{'att'}->{'head'}}};
        foreach my $at (keys %atrb)
        {
           if(($at ne "new_id")&&($at ne "head"))
           { $element->set_att( $at => $atrb{$at}); }
        }
      }
    }
    if(exists $element->{'att'}->{'form'})
    {
      if(exists $propagate{$element->{'att'}->{'form'}})
      {
        $element->set_att( 'form'=>$propagate{$element->{'att'}->{'form'}}{'form'} );
      }
    }
    if(exists $element->{'att'}->{'comp'})
    {
      if(exists $propagate{$element->{'att'}->{'comp'}})
      {
        $element->set_att( 'comp'=>$propagate{$element->{'att'}->{'comp'}}{'comp'} );
      }
    }
    if(exists $element->{'att'}->{'exsubj'})
    {
      if(exists $propagate{$element->{'att'}->{'exsubj'}})
      {
        $element->set_att( 'exsubj'=>$propagate{$element->{'att'}->{'exsubj'}}{'exsubj'} );
      }
    }
    if(exists $element->{'att'}->{'gapreq'})
    {
      if(exists $propagate{$element->{'att'}->{'gapreq'}})
      {
          $element->set_att( 'gapreq'=>$propagate{$element->{'att'}->{'gapreq'}}{'gapreq'} );
      }
    }
    if(exists $element->{'att'}->{'realform'})
    {
      if(exists $propagate{$element->{'att'}->{'realform'}})
      {
          $element->set_att( 'realformg'=>$propagate{$element->{'att'}->{'realform'}}{'realform'} );
      }
    }
  }
  else
  {
  #print "Finding and Parsing Node: $element->{'att'}->{'cat'}\n";
  #pprint($element,"OUT");
  @ret_value=();
  pprint($element,"TRACE");
  #pprint($element,"OUT");
  if($element->att('parsed') ne '1')
  {
    #pprint($element,"TRACE");
    my @selected;

    #get the cat of the current element.
    my $type = $element->{'att'}->{'cat'};

    #find all the rules in the ruleset which have the same cat
    foreach my $k (sort keys %ruleset)
    {
      if($ruleset{$k}{'antecedent'}{'name'} eq $type)
      {
        ######if the antecedent rule contains attributes, check if these
        ######attributes are present in the XML node, push into @selected
        ######only if the attributes are present
        my $push=1;
        if(exists $ruleset{$k}{'antecedent'}{'attribute'})
        {
          my %atr = %{$ruleset{$k}{'antecedent'}{'attribute'}};

          foreach my $a (keys %atr)
          {
            if((!exists $element->{'att'}->{$a})&&($a ne "new_id"))
            {
              $push=0;
            }
          }
        }
        if($push ==1)
        {
           push(@selected,$k);
        }

      }
    }
    #Find the Axiom that matches the current structure adn set final=1
    my @selected = sort {$a <=> $b} @selected;
    my $found_rule=-1;
    my $rule_num;
    %propagate=();
    #pprint($element,"OUT");
    my $global=0;
    for(my $s=0;$s<=$#selected && $found_rule==-1;$s++)
    {
      my $element_copy = $element->copy();


      #debugging
      $global=0;
      #if($ruleset{$selected[$s]}{'org_num'} eq "5221")
      #{
      #  print "here\n";
      #  $global=1;
      #}
      @ret_value=();
      #print TRACE $ruleset{$selected[$s]}{'org_num'}."   ";
      @ret_value = matchLHS($element_copy,%{$ruleset{$selected[$s]}{'antecedent'}});
      $found_rule= $#ret_value;
      #print $ruleset{$selected[$s]}{'org_num'}."\n";

      if($found_rule>-1)
      {
        $rule_num=$selected[$s];
      }
    }
    if($found_rule>=0)
    {
      print TRACE "\nrule found: ".$ruleset{$rule_num}{'org_num'}."\n\n";
      #print "\nrule found: ".$ruleset{$rule_num}{'org_num'}."\n\n";

      #print "\nrule found: ".$ruleset{$rule_num}{'org_num'}."\n";
      my ($newXML,%selected_cons);
      %selected_cons=();
      %selected_cons= %{$ruleset{$rule_num}{'consequent'}};
      my %sel_cons_clone;

      $newXML = makeNewXML(%selected_cons);
      #if($global==1)
      #{
      #  $newXML->print();
      #}
      my %atrs = %{$element->{'att'}};
      foreach my $at (keys %atrs)
      {
         if($at ne "cat")
         {
            if(!exists $newXML->{'att'}->{$at})
            {
              $newXML->set_att($at,$atrs{$at});
            }
         }
      }

      $newXML->set_att('parsed','1');
      pprint($newXML,"TRACE");
      print TRACE "\n---------------------\n\n";
      #pprint($element,"OUT");
      #pprint($newXML,"OUT");
      $newXML->replace($element);
      #pprint($twig,"OUT");
      $change=1;
    }
  }
  }
}


sub makeNewXML
{
  my (%consequent)=@_;
  my ($head,$cat);
  $cat = $consequent{'name'};
  #print TRACE $cat ."\n\n";
  if($cat=~/^([0-9])$/)
  {
    my $arg = $1;
    $head = new XML::Twig::Elt('dummy');
    $head->set_att('cat','dummy');
    my @ma;
    if(exists $ret_value[$arg])
    { @ma = @{ $ret_value[$arg] }; }
    my $max=$#ma;
    my $mcopy;
    for(my $m=0;$m<=$max;$m++)
    {
      $ma[$m]->cut;
      $mcopy = $ma[$m]->copy();
      $mcopy->paste('last_child',$head);
    }
    # if it is a cover node, add the parsed=1 attribute
    #if any other node, add attr value to first node
  #if($consequent{'name'} == 3)
  #{
  #  print "ok";
  #}
    if((exists $consequent{'attribute'}))#&&($#ma==0))
    {

      my %attr = %{$consequent{'attribute'}};
      foreach my $at (keys %attr)
      {
        my $val = $attr{$at};
        if($at eq "parsed")
        {
          $head->first_child->set_att($at,$attr{$at});
        }
        elsif(($val=~ /^(\d+)$/))
        {
          my $num = $1;
          if($num <= $#ret_value)
          {
            my $ma = $ret_value[$num][0];
            if(exists $ma->{'att'})
            {
              my %attrb=(); %attrb = %{$ma->{'att'}};
              $head->first_child->set_att($at,$attrb{$at});
            }
          }
          else
          {
            if((exists $propagate{$val}))
            {
              $head->first_child->set_att($at,$propagate{$val});
            }
            else
            {
              if(!exists $in_system{$propagate{$val}})
              {
                my $ctr = "n".$atr_counter;
                $propagate{$val}=$ctr;
                if($at eq "new_id")
                {
                  foreach my $k (keys %attr)
                  {
                    if(($k ne "arity")&&($k ne "tokenStart")&&($k ne "tokenEnd")&&($k ne "Mention")&&($k ne "parsed")&&($k ne "new_id")&&($k ne "head"))
                    {$in_system{$ctr}{$k}=$attr{$k};}
                  }
                }
                else
                {
                  $in_system{$ctr}=1;
                }
                if(!exists $in_system{$ctr})
                {
                  $in_system{$ctr}=1;
                }
                $head->first_child->set_att($at,$ctr); $atr_counter++;
              }
            }
          }
        }
        else
        {
          $head->first_child->set_att($at,$attr{$at});
        }
      }
    }
  }
  else
  {
    $head = new XML::Twig::Elt($consequent{'name'});
    $head->set_att('cat',$consequent{'name'});
  }

  if(exists $consequent{'attribute'})
  {
    my %attributes =();
    %attributes = %{ $consequent{'attribute'} };
    foreach my $x (keys %attributes)
    {
      #if attribute is a number, get the attributes matching with that numbered
      #node, as attributes of the current node
      if(($attributes{$x} =~ /^([0-9*])$/)&&($x ne "arity")&&($x ne "tokenStart")&&($x ne "tokenEnd")&&($x ne "Mention")&&($x ne "parsed"))
      {
        #print TRACE $x."  ".$attributes{$x}."\n";
        my $arg = $1;
        $arg++;$arg--; #to convert to a number in perl
        if($arg > $#ret_value)
        {
          if((exists $propagate{$arg}))
          {
            $head->set_att($x,$propagate{$arg});
          }
          else
          {
            if(!exists $in_system{$propagate{$arg}})
            {
              my $ctr = "n".$atr_counter;
              $propagate{$arg}=$ctr;
              if($x eq "new_id")
              {
                foreach my $k (keys %attributes)
                {
                  if(($k ne "arity")&&($k ne "tokenStart")&&($k ne "tokenEnd")&&($k ne "Mention")&&($k ne "parsed")&&($k ne "new_id")&&($k ne "head"))
                  {$in_system{$ctr}{$k}=$attributes{$k};}
                }
              }
              else
              {
                $in_system{$ctr}=1;
              }
              if(!exists $in_system{$ctr})
              {
                $in_system{$ctr}=1;
              }
              $head->set_att($x,$ctr); $atr_counter++;
            }
          }
        }
        else
        {
          my $ma = $ret_value[$arg][0];
          #if $attributes{$x} is head, then copy all attributes, else copy selected attributes
          if(exists $ma->{'att'})
          {
            if($x eq "head")
            {
              my %attr=(); %attr = %{$ma->{'att'}};
              foreach my $atr (keys %attr)
              {
                if(($atr ne "new_id")&&($atr ne "cat")&&($atr ne "lex")&&($atr ne "")&&($atr ne "parsed")&&($atr ne "tokenStart")&&($atr ne "tokenEnd")&&($atr ne "Mention")&&($atr ne "parsed"))
                { $head->set_att($atr,$attr{$atr}); }
              }
            }
            else
            {
              $head->set_att($x,$ma->{'att'}->{$x});
            }
          }
        }
      }
      else
      {
        #print TRACE $x."  ".$attributes{$x}."\n";
        $head->set_att($x,$attributes{$x});
      }
    }
  }
  if(exists $consequent{'children'})
  {
    my @children = @{ $consequent{'children'} };
    foreach my $c (@children)
    {
      my $child_new = makeNewXML(%{$c});
      #$child_new->print();
      if($child_new->{'att'}->{'cat'} eq "dummy")
      {
        my @children_new = $child_new->children();
        foreach my $cn (@children_new)
        {
          $cn->cut();
          $cn->paste('last_child',$head);
        }
        my %atr = %{$child_new->{'att'}};
        #foreach my $a (keys %atr)
        #{
        #  if($a ne 'cat')
        #  {
        #    $head->first_child->set_att($a,$atr{$a});
        #  }
        #}
      }
      else
      {
        $child_new->paste('last_child',$head);
      }
    }
  }
  %consequent=();
  return($head);
}

sub matchLHS
{
  my ($element1,%curr_rule) = @_;
  my (@XML_children,@rule_children,@matched_nodes);

  #if(stringMatch($curr_rule{'name'},$element1->{'att'}->{'cat'});

  if(exists $curr_rule{'children'})
  {
    @XML_children=$element1->children();
    @rule_children=@{$curr_rule{'children'}};
  }
  #Check if children in curr_rule have final children and no other children
  if($curr_rule{'finalChildren'} eq "true")
  {
    #the children within this are leaf nodes in the rule provided.
    #match the rule with the structure in the XML tree
    #return the matched pairs of rule-xml structure to the calling function
    my ($next,$xml_counter);
    $next=0; $xml_counter=-1;
    #if LHS is single node

    if(($#rule_children == -1)&&($#XML_children == -1))
    {
     #match parent
      my ($name_match,$attr_match);
      $name_match=0; $attr_match=1;
      $name_match = stringMatch($curr_rule{'name'},$element1->{'att'}->{'cat'});
      if(exists $curr_rule{'attribute'})
      {
         foreach my $atr (keys %{$curr_rule{'attribute'}})
         {
            if($atr ne "new_id")
            {
              if((!exists $element1->{'att'}->{$atr})||
              (!stringMatch($element1->{'att'}->{$atr},$curr_rule{'attribute'}{$atr})))
              { $attr_match=0; }
            }
         }
      }
      if((!$name_match)||(!$attr_match))
      {
         return(my @dummy);
      }
      else
      {
         #add the mapping results into matched array
         #return the array to the calling function
         $matched_nodes[$curr_rule{'index_num'}]=[ $element1 ];
      }
      return(@matched_nodes);
    }
#    else
#    {
#      #match parent
#      my ($name_match,$attr_match);
#      $name_match=0; $attr_match=1;
#      $name_match = stringMatch($curr_rule{'name'},$element1->{'att'}->{'cat'});
#      if(exists $curr_rule{'attribute'})
#      {
#         foreach my $atr (keys %{$curr_rule{'attribute'}})
#         {
#            if($atr ne "new_id")
#            {
#              if((!exists $element1->{'att'}->{$atr})||
#              (!stringMatch($element1->{'att'}->{$atr},$curr_rule{'attribute'}{$atr})))
#              { $attr_match=0; }
#            }
#         }
#      }
#      if((!$name_match)||(!$attr_match))
#      {
#         return(my @dummy);
#      }
#      else
#      {
#         #add the mapping results into matched array
#         #return the array to the calling function
#         if(exists $curr_rule{'attribute'}{'new_id'})
#         {
#            $element1->set_att('new_id',$curr_rule{'attribute'}{'new_id'});
#         }
#         $matched_nodes[$curr_rule{'index_num'}]=[ $element1 ];
#      }
#    }
    if(($#rule_children <= $#XML_children)&&($#rule_children != -1))
    {
      for(my $l=0;$l<=$#rule_children&&$next==0;$l++)
      {
        $xml_counter++;
        if($rule_children[$l]{'name'} eq "...")
        {
          my @tmpArray;
          if($l == $#rule_children)
          {
            #this is the last element in the rule, assign the remaining XML
            #nodes to this element
            while($xml_counter<=$#XML_children)
            {
               push(@tmpArray,$XML_children[$xml_counter]);
               $xml_counter++;
            }
            my $arg = $rule_children[$l]{'index_num'};
            $matched_nodes[$arg]=\@tmpArray;
          }
          else
          {
            #this ... is not the last element in the list
            #map this ... with all the elements upto the max possible matchings possible
            my $max_possible = $#rule_children-$l;
            while($xml_counter<=($#XML_children-$max_possible))
            {
              push(@tmpArray,$XML_children[$xml_counter]);
              $xml_counter++;
            }
            $xml_counter--;
            my $arg = $rule_children[$l]{'index_num'};
            $matched_nodes[$arg]= \@tmpArray;
          }
        }
        else
        {
          my ($name_match,$attr_match);
          $name_match=0;$attr_match=1;
          #check whether the name in rule matches the name in the XML node
          $name_match = stringMatch($rule_children[$l]{'name'},$XML_children[$xml_counter]{'att'}{'cat'});
          #check if the attributes are the same
          if(exists $rule_children[$l]{'attribute'})
          {
            foreach my $atr (keys %{$rule_children[$l]{'attribute'}})
            {
              if((!exists $XML_children[$xml_counter]{'att'}{$atr})||
              (!stringMatch($XML_children[$xml_counter]{'att'}{$atr},$rule_children[$l]{'attribute'}{$atr})))
              { $attr_match=0; }
            }
          }
          if((!$name_match)||(!$attr_match))
          {
            return(my @dummy);
          }
          else
          {

            #add the mapping results into matched array
            #return the array to the calling function
            $matched_nodes[$rule_children[$l]{'index_num'}]=[ $XML_children[$xml_counter] ];
          }
        }
      }
      if($xml_counter >= $#XML_children)
      {
        #make sure all XML nodes are used before returning
        return(@matched_nodes);
      }
      else
      {
        return(my @dummy);
      }
    }
    else
    {
       return(my @dummy);
    }
  }
  else
  {
    #all children of the rule and XML_children must be the same and equal in number.
    #iterate over each child and get the matching pairs
    my @matched_final;
    if($#XML_children == $#rule_children)
    {
      for(my $rc=0;$rc<=$#rule_children;$rc++)
      {
        #check if this rule-childname equals the XML childname
        if($rule_children[$rc]{'name'} eq $XML_children[$rc]{'att'}{'cat'})
        {
          my @matched = matchLHS($XML_children[$rc],%{$rule_children[$rc]});
          $matched_final[$rc]=\@matched;
        }
        else
        {
          return(my %dummy);
        }
      }
    }
    else
    {
      return(my %dummy);
    }
    return(@matched_final);
  }
}

sub makeStructure
{
  my ($current,$distinguisher) = @_;
  my (%hpar,$counter,$name);
  $counter=0;
  while($current =~ /\(([^\(\)]+)\)/ )
  {
    $counter++;
    my ($parent,$curr_element,@innermost,$parent,@charray,%currpar,@children,%hchild);
    $curr_element = $1;
    @innermost = split(/ /,$1);
    if($#innermost == 0)
    {
      if($innermost[0] =~ /(.*):([0-9]*)/)
      {
        my $name = $1;
        my @attrs = split(/@/,$name);
        $currpar{'name'}=$attrs[0];
        for(my $a=1;$a<=$#attrs;$a++)
        {
          my @key_val = split(/=/,$attrs[$a]);
          $key_val[1]=~ s/"//g;
          $currpar{'attribute'}{$key_val[0]}=$key_val[1];
        }
        $currpar{'index_num'}=$2;
      }
    }
    else
    {
      #parsing parent of innermost structure
      my ($par,$index);
      if($innermost[0] =~ /(.*):([0-9]*)/)
      {
        $par=$1;
        $currpar{'attribute'}{'new_id'}=$2;
        $currpar{'index_num'}=$2;
      }
      else
      {
        $par=$innermost[0];
      }
      my (@attr,@values,%attributes);
      @attr = split(/\@/,$par);
      $currpar{'name'}=$attr[0];
      for(my $k=1;$k<=$#attr;$k++)
      {
        @values=split(/=/,$attr[$k]);
        $values[1]=~ s/"//g;
        $attributes{$values[0]}=$values[1];
      }
      if((keys %attributes) >0 )
      {
        foreach my $a (keys %attributes)
        {
          $currpar{'attribute'}{$a}= $attributes{$a};
        }
      }
      $parent=$attr[0];
    }
    #parsing children of innermost structure
    my $root_parent=1;
    for(my $r1=1;$r1<=$#innermost;$r1++)
    {
      my %child1;
      if($innermost[$r1] =~ /POP\-([a-zA-Z0-9]*):([0-9]*)/)
      {
         $child1{'name'}=$1;
         my $tmp = $1.":".$2;
         $child1{'children'}=\@{$hpar{$tmp}{'children'}};
         $child1{'attribute'} =\%{$hpar{$tmp}{'attribute'}};
         $child1{'parent'}=$currpar{'name'};
         if(exists $hpar{$tmp}{'new_id'})
         {
            $child1{'new_id'}=$hpar{$tmp}{'new_id'};
         }
         if(exists $hpar{$tmp}{'finalChildren'})
         {
            $child1{'finalChildren'}="true";
         }
         delete $hpar{$tmp};
         $root_parent=0;
      }
      else
      {
         #assign attributes and numbers to the antecedents
         #assigning index number
         my $par;
         if($innermost[$r1] =~ /(.*):([0-9]*)/)
         {
            #assigning the name and attributes
            $child1{'index_num'}=$2;
            $par=$1;
         }
         else
         { $par = $innermost[$r1];}

         my @name_attributes = split(/\@/,$par);
         $child1{'name'}=$name_attributes[0];
         for(my $a=1;$a<=$#name_attributes;$a++)
         {
           my @atr = split(/=/,$name_attributes[$a]);
           $atr[1] =~ s/"//g;
           $child1{'attribute'}{$atr[0]}=$atr[1];
         }
         $child1{'parent'}=$currpar{'name'};
      }
      push(@charray,\%child1);
    }
    $name=$currpar{'name'}.":$counter";

    #replace the already parsed child with the POP-[PARENT]:[ID] structure
    my $srch = "(".$curr_element.")";
    my $repl = "POP-$parent:$counter";
    $srch =~ s/([\(\)\\\|\[\{\^\$\*\+\?\.\@\=])/\\\1/g;
    $repl =~ s/([\(\)\\\|\[\{\^\$\*\+\?\.\@\=])/\\\1/g;
    $current =~ s/$srch/$repl/;
    if($#charray >= 0)
    { $currpar{'children'}=\@charray; }
    if($root_parent)
    {
      $currpar{'finalChildren'}="true";
    }
    $hpar{$name}={ %currpar};
  }
  #my %tmphash = %{ $hpar{$name} };
  return(%{ $hpar{$name} });
}

sub pprint
{
  my ($ele,$place)=@_;
  $ele->set_pretty_print( 'indented');
  if($place eq "OUT")
  {
    $ele->print();
    print "\n";
    #print "\n-----------------\n";
  }
  else
  {
    $ele->print(\*TRACE);
    print TRACE "\n";
    #print TRACE "\n-------------------\n";
  }
}
sub stringMatch
{
  my ($string1,$string2)=@_;
  $string1 =~ s/"//g;
  $string2 =~ s/"//g;
  if($string1 eq $string2)
  {
    return(1);
  }
  else
  {
    return(0);
  }
}
sub parseBraces
{
  my($current) = @_;
  my $open = ($current =~ tr/(/(/);
  my $close = ($current =~ tr/)/)/);
  if($open == $close)
  {
    return($open);
  }
  else
  {
    return(-1);
  }
}
