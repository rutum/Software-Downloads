#!/usr/bin/perl

use strict;

if($#ARGV != 1 )
{
	print "Usage: perl reorderLogicalForms.pl <input file> <output file>\n";
}
else
{
	open (IN,"$ARGV[0]");
	open (OUT,">$ARGV[1]");
	while(my $x = <IN>)
	{
		if($x =~ /\w+\'\(.*\)/)
		{
			my %LFTerms;
			chomp($x);
			my $lfLine = $x;
			my @terms = split(" & ",$lfLine);
			my @blanks;
			foreach my $t (@terms)			
			{
				my ($lForm,$index) = split("_",$t);
				if($index == "")
				{
					# if something doesnt have an index, group it with something else
					# what are the different types of non indexed words possible?
					#print $lForm."\n";
					push(@blanks,$lForm);	
				}
				else
				{
					$LFTerms{$index}{$lForm}=1;
				}
			}
      if($#blanks > 0)
      {
        print OUT "0)";
			  foreach my $w (@blanks)
			  {
				  print OUT $w."    ";
			  }
		    print OUT "\n";
      }
			foreach my $key (sort {$a <=> $b} keys %LFTerms)
			{
				print OUT "$key) ";
        my %LFinside = %{ $LFTerms{$key}};
        foreach my $lfi (keys %LFinside)
        {
          print OUT "$lfi ";
        }
        print OUT "\n";
			}
			print OUT "\n-------------\n";
			%LFTerms=();
		}
	}
	close(OUT);
	close(IN);
}

