use strict;
if(@ARGV != 3)
{
  print "\nUsage: \n";
  print "perl NL.pl <input file> <output file prefix> \"parse\"|\"xml1\"|\"xml2\"|\"lftoolkit\"|\"mt\"|\"graph\"\n";
  exit(0);
}
elsif((@ARGV ==3) && ($ARGV[2] eq "delete"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  deletefiles($ARGV[1]);
}
elsif((@ARGV ==3) && ($ARGV[2] eq "parse"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  deletefiles($ARGV[1]);
  parse($charniak_input,$outname);
  xml($outname);
  binarize($outname);
  lftoolkit($outname);
  format_for_tacitus($outname);
  #tacitus();
}
elsif((@ARGV ==3) && ($ARGV[2] eq "xml1"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  xml($outname);
  binarize($outname);
  lftoolkit($outname);
  format_for_tacitus($outname);
  #tacitus();
}
elsif((@ARGV ==3) && ($ARGV[2] eq "xml2"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  binarize($outname);
  lftoolkit($outname);
  format_for_tacitus($outname);
  tacitus();
}
elsif((@ARGV ==3) && ($ARGV[2] eq "lftoolkit"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  lftoolkit($outname);
  format_for_tacitus($outname);
  tacitus();
}
elsif((@ARGV ==3) && ($ARGV[2] eq "mt"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  format_for_tacitus($outname);
  tacitus();
}
elsif((@ARGV ==3) && ($ARGV[2] eq "graph"))
{
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  my $cmd;
  print "\nConverting to graph";
  $cmd = "perl NL-Module\\makeGraph\\makeGraph.pl $outname"."_LFT.txt $outname"."_graph";
  system($cmd);
  $cmd = "dot -Tjpg out_graph.txt > gr.jpg";
  system($cmd);
}

sub deletefiles()
{
  my ($target) = @_;
  print "Deleting all existing files...: $target ...";
  opendir(DIR,"output");
  my @files = readdir(DIR);
  foreach my $file (@files)
  {
    if(($file ne ".")&&($file ne "..")&&($file ne ".svn"))
    {
      my $str = "output/".$file;
      unlink($str);
    }
  }
  close(DIR);
  opendir(DIR1,"input");
  @files = readdir(DIR1);
  foreach my $file (@files)
  {
    if(($file ne ".")&&($file ne "..")&&($file ne ".svn"))
    {
      my $str = "input/".$file;
      unlink($str);
    }
  }
  close(DIR1);
  unlink('trace.txt');
  my $cmd = $target."_chin.txt";
  unlink($cmd);
  $cmd = $target."_char.txt";
  unlink($cmd);
  $cmd = $target."_xml1.xml";
  unlink($cmd);
  $cmd = $target."_xml2.xml";
  unlink($cmd);
  $cmd = $target."_LFT.txt";
  unlink($cmd);
  $cmd = $target."_LFT_HUMAN.txt";
  unlink($cmd);
  print "..done!\n";
}
sub parse()
{
  my ($ch_input,$outn) = @_;
  print "Parsing the text...";
  my $cmd = "NL-Module\\Parser\\PARSE\\parseIt.exe -P NL-Module\\Parser\\DATA\\EN\\ $ch_input > $outn"."_char.txt";
  my $time = time;
  system($cmd);
  my $elapsed_seconds = time - $time;
  print " ...done! ($elapsed_seconds seconds)";
}
sub xml()
{
  my ($time,$cmd,$elapsed_seconds);
  my ($outn) = @_;
  print "\nConverting parse tree to XML...";
  $cmd = "perl NL-Module\\parse2xml.pl rules\\dictionary.text $outn"."_char.txt $outn"."_xml1.xml";
  $time = time;
  system($cmd);
  $elapsed_seconds = time - $time;
  print " ...done! ($elapsed_seconds seconds)";
}
sub binarize()
{
  my ($outn) = @_;
  my ($time,$cmd,$elapsed_seconds);
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  print "\nBinarizing XML parses...";
  $cmd = "perl NL-Module\\tree_transformer_new.pl rules\\tree-transformations.text $outn"."_xml1.xml $outn"."_xml2.xml";
  $time = time;
  system($cmd);
  $elapsed_seconds = time - $time;
  print " ...done! ($elapsed_seconds seconds)";
}
sub lftoolkit()
{
  my ($outn) = @_;
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  my ($time,$cmd,$elapsed_seconds);
  print "\nConverting to Logical Form...";
  $cmd = "java -jar NL-Module\\LFToolkit.jar  rules\\rules-LFT-new.txt $outn"."_xml2.xml $outn"."_LFT.txt";
  system($cmd);
  print "\nConverting Logical Form to human readable form ...";
  $cmd = "perl NL-Module\\reorderLogicalForms.pl $outn"."_LFT.txt $outn"."_LFT_HUMAN.txt";
  system($cmd);
  print " ...done!";
  print "\n\n";
}
sub format_for_tacitus($outname)
{
  my ($outn) = @_;
  my $charniak_input = $ARGV[0];
  my $outname= $ARGV[1];
  my ($time,$cmd,$elapsed_seconds);
  print "\nConverting the output for Mini-TACITUS...";
  $cmd = "perl NL-Module\\format_for_tacitus.pl $outn"."_LFT.txt input 20";
  system($cmd);
  print " ...done!";
}
sub tacitus
{
  print "\nAbducing using Mini-TACITUS";
  opendir(DIR,"input");
  my @files = readdir(DIR);
  my ($time,$cmd,$elapsed_seconds);
  foreach my $file (@files)
  {
    if(($file ne ".")&&($file ne ".."))
    {
      #run tacitus on this file
      print $file."\n";
      my $cmd = "java -jar NL-Module\\Mini-Tacitus.jar rules\\axioms.txt input\\".$file." output";
      print $cmd."\n";
      system($cmd);
    }
  }
  print " ...done!";
}
