18

  1   mt     0  0 |
  2   mtu    1  1 |
  3   mtuc   2  2 |
  4   mtucvE 3  3 |
  5   mtucvb 4  4 |
  6   mtucvm 5  4 |
  7   mtuch  6  3 |

--

  0    t   0  1 |
  1    u   2  2 |
  2    c   12 3 |
  3    vE  24 4 |
  4    b   7  5 |
  5    m   9  6 |
  6    h   3  7 | 

--
