/*
 * Axiom.java
 *
 * Created on March 21, 2008, 10:50 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
import java.util.regex.*;

/**
 * This class deals with all the functions and data structures related to 
 * the Axioms used in the system. 
 * Format of an Axiom is:
 *  axiom number] prop1(e1,x1):cost -> prop2(e1,e2):cost |sNM1
 * 
 * @author Rutu Mulkar-Mehta
 */
public class Axiom 
{
    /** String representation of the axiom number. */
    String sAxNum;
    /** The list of propositions in the antecedent of the Axiom */
    ArrayList alAntecedent;
    /** The list of propositions in the consequent of the Axiom */
    ArrayList alConsequent;  
    //ArrayList alOtherConses; not used anymore
    /** The arguments in the Axiom which are actually sNM1 */
    Hashtable hConstants;
    /** The arguments in the Axiom that cannot be merged with each other */    
    Hashtable hNoMerge;
    /** Creates a new instance of Axiom */
    public Axiom()
    {
        sAxNum = new String();
        alAntecedent = new ArrayList();
        alConsequent= new ArrayList();
        //alOtherConses = new ArrayList(); not used anymore
        hConstants = new Hashtable();
        hNoMerge=new Hashtable(); 
    }
    
    /**
     * Takes the string representation of the Axiom and stores it in the Axiom
     * data structure. 
     * 
     * @param s String representation of the Axiom
     *          <br>
     *          axiom number] prop1(e1,x1):cost -> prop2(e1,e2):cost |sNM1
     *          <br>
     *          If there are no sNM1, a space is left instead.
     * @return  True if the syntax is correct, False if the syntax is incorrect
     */
    
    boolean setAxiom(String s) 
    {  
        Print p = new Print();
        Pattern pattern = Pattern.compile("\\d*\\w*\\](.*)->(.*)\\|(.*)");
        Matcher matcher = pattern.matcher(s);
        boolean bool = matcher.matches();
        if(!bool) { System.err.println("AXIOM: Illegal axiom format."); return(false); }
        Pattern pattern1 = Pattern.compile("->|\\]|\\|");
        String[] items = pattern1.split(s);
        String sAntecedent = new String();
        String sConsequent = new String();
        String sAxNoMerge = new String();

        /*Set the axiom number*/
        this.sAxNum = items[0]; 
        if(Main.axioms.containsKey(this.sAxNum))
        {
            System.err.println("Axiom: Duplicate axiom numbers: "+this.sAxNum);
            return(false);
        }
        if(items.length == 4)
        {
        sAntecedent = items[1]; 
        sConsequent = items[2]; 
        sAxNoMerge = items[3];
        }
        else
        {
            System.err.println("Axiom: Illegal Axiom format: "+this.sAxNum);
            return(false);
        }
        /*Set the props in the LHS*/                    
        Pattern LhsRhs = Pattern.compile(" & ");
        String[] props1 = LhsRhs.split(sAntecedent);            
        for(int i=0;i<props1.length;i++)
        {
            Prop p1 = new Prop();
            boolean b = p1.setProp(props1[i]);
            if(!b) { System.err.println("AXIOM: Illegal proposition format: "+props1[i]); return(false); }
            this.alAntecedent.add(p1);
        }

        /*Set the props in the RHS*/
        String[] props2 = LhsRhs.split(sConsequent);
        for(int i=0;i<props2.length;i++)
        {
            Prop p1 = new Prop();
            boolean b = p1.setProp(props2[i]);
            if(!b) { System.err.println("AXIOM: Illegal proposition format: "+props1[i]); return(false); }
            this.alConsequent.add(p1);
        }
     
        /*Set the NoMerge for the Axioms*/
        if(!sAxNoMerge.equals(" "))
        {
            Pattern pNM = Pattern.compile(",");
            String[] sNM1 = pNM.split(sAxNoMerge);
            for(int i=0;i<sNM1.length;i++)
            {
                Pattern pNM2 = Pattern.compile("-");
                String[] sNM2 = pNM2.split(sNM1[i]);
                Hashtable h2 = new Hashtable();
                h2.put(sNM2[1], "1");
                this.hNoMerge.put(sNM2[0],h2);
            }           
        }
        else
        {
            this.hNoMerge=new Hashtable();
        }
        return(true);
    }
}
