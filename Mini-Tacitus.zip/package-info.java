/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Mini-TACITUS (The Abductive Commonsense Inference Text Understanding System).
 * This is a Java based implementation of the original Lisp code of TACITUS by 
 * Dr. Jerry R. Hobbs. TACITUS is essentially an abduction engine, which means 
 * that it backchains on propositions rather than forward chaining on them (like
 * deduction). A very simple example of abduction is the chain of thought
 * followed by Sherlock Holmes. He backchained on his current knowledge, to get 
 * the best explanation for that scenario, finally coming up with a solution
 * set. Out of these solutions he picked the solution which was most befitting
 * to the situation, and that explained most of the happenings in the Scenario. 
 * <br><br>
 * TACITUS is our attempt to explain this abductive process using Props 
 * (Propositions) and weights/costs assigned to each proposition. The cost of an 
 * Interpt (interpretation), is the sum of the costs of all the Props within 
 * it. 
 * <br><br>
 * FEATURES OF Mini-TACITUS:<br>
 * 1) Finding duplicate Interpretations
 * 2) Specifying arguments that cannot be merged
 * 3) Allowing constants in the Interpretations
 * @author Rutu Mulkar-Mehta
 * 
 */
package minitacitus;

