/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package minitacitus;
import java.io.*;
import java.util.*;
import java.util.regex.*;
/**
 * This is the first class called when the engine is started. It performs all
 * the miscellaneous functions of reading axioms, scenaio from text files,
 * and calling the function to proliferate the scenario to get new Interpts.
 * 
 * @author Rutu Mulkar-Mehta
 */
public class Main 
{
    /** Sets the automatic ID of new props added to the Interpretation.
     * Starts with 1000. */
    static int iMaxID=1000;
    /** Default depth assigned, if no use input is provided */
    static int depth=3;
    /** Default time is assigned if no time cutoff is specified */
    static long time=999999;
    /** Prop ID starting with 99 */
    static int ipid;
    /** Axiom filename */
    static String axiomFile;
    /** Scenario File */
    static String scFile;
    /** Output directory */
    static String outDir;
    /** Set of Axioms read from the Axioms file */
    static Hashtable axioms = new Hashtable();
    /** Scenario read form the Scenario file. There can be only one scenario 
     * in a single scenario file. */
    static Hashtable scenarios=new Hashtable();    
    /** Hashtable indexed by the fingerprint of each Interpt */
    static Hashtable quickSearchInterpt = new Hashtable();    
    /** Hashtable containing all Interpts */
    static Hashtable hInterpt = new Hashtable();    
    /** Current Interpt counter */
    static int interptCounter=0;
    /** Stack containing the list of Interpretations from the Scenario */
    static ArrayList alStack = new ArrayList();
    /** Parameter Hashtable */
    static Hashtable hParams=new Hashtable();
    /** Location where the comments can be printed */
    static String location = new String();
    static BufferedWriter bwOut ;
    /**
     * Main executable when the Engine is started
     * @param args  <br>
     *          Axiom:<Axiom file name>
     *          Scenario:<scenario file location and name>
     *          Output:<output directory location>
     *          Depth:<Depth of interpretation>
     *          Time:<Time in minutes after which process should be aborted>
     *          Location:<Location where the trace should be printed>
     *              options: suppress|stdout|file
     */
    public static void main(String[] args) 
    {
        Print p = new Print();
        try
        {
             bwOut = new BufferedWriter(new FileWriter("MT-Trace.txt"));
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        for(int i=0;i<args.length;i++)
        {
            Pattern ax = Pattern.compile(":");
            String[] sParams = ax.split(args[i]);
            hParams.put(sParams[0],sParams[1]);
        }
        Enumeration eP = hParams.keys();
        while(eP.hasMoreElements())
        {            
            String sp = (String)eP.nextElement();
            if(sp.equals("Axiom")) { axiomFile = (String)hParams.get(sp); }
            if(sp.equals("Scenario")) { scFile = (String)hParams.get(sp); }
            if(sp.equals("Output")) { outDir = (String)hParams.get(sp); }
            if(sp.equals("Depth"))
            {
                try
                { depth = Integer.parseInt((String)hParams.get(sp)); }
                catch(NumberFormatException e)
                {   p.Usage(); System.exit(0); }
            }
            if(sp.equals("Time"))
            {
                try
                { time = Integer.parseInt((String)hParams.get(sp)); }
                catch(NumberFormatException e)
                {   p.Usage(); System.exit(0); }
            }
            if(sp.equals("Location"))
            {
                location = (String)hParams.get(sp);
            }
        }
        if(!(hParams.containsKey("Axiom") && hParams.containsKey("Scenario") && hParams.containsKey("Output")))
        { p.Usage(); System.exit(0); }
                      
        iMaxID =0;        
        readScenario(scFile);
        readAxiom(axiomFile);
        proliferate();
        String tmp = scFile;
        System.out.println(scFile);
        String fs = (String)System.getProperty("file.separator");
        System.out.println(fs);
        tmp = tmp.replaceAll("input","");
        tmp = tmp.replaceAll(fs,"");
        tmp = tmp.replaceAll(".txt","");
        System.out.println(tmp);
        /*proliferation is done, print the interpreations*/
        p.printAllInterptsHTML(outDir+fs+tmp+"-tree.html");
        p.printBestInterpt(outDir+fs+tmp+"-best.txt");
    }
    /**
     * Main function which finds the interpretations of the input text/logical
     * form
     * <br>
     * <b>Algorithm</b>
     */
    static void proliferate()
    {
        int i=0;
        /*find all the axioms that can be applied to the current interpretation*/
        Binding b1 = new Binding();
        Print p = new Print();
        //Get the current interpt for which Axioms need to be found
        String currCounter= new String("0");
        long begin = System.currentTimeMillis();
        while(alStack.size()>0)
        {
            long now = System.currentTimeMillis();
            if((now-begin)/60000 < time)
            {
                currCounter = (String)alStack.get(alStack.size()-1);
                alStack.remove(alStack.size()-1);
                p.print(location, "MAIN: Evaluating interpt: "+ currCounter, bwOut);
                /*get the props -l2, from the interpt in currCounter*/

                if((hInterpt.containsKey(currCounter))&&(!(((Interpt)hInterpt.get(currCounter)).bDuplicate)))
                {
                    ArrayList l2 = (ArrayList)((Interpt)hInterpt.get(currCounter)).alProps;
                    /*chcek all the Axioms if they match the current Interpt*/
                    Enumeration e = Main.axioms.keys();
                    boolean flag = false;
                    while(e.hasMoreElements() && !flag)
                    {
                        String sAxNum = (String)e.nextElement();
                        
                        //p.printInterpt((Interpt)hInterpt.get(currCounter));
                        //if(!((Interpt)hInterpt.get(currCounter)).hAxiomsUsed.containsKey(sAxNum))
                        Axiom ax = (Axiom)Main.axioms.get(sAxNum);
                        ArrayList l1 = (ArrayList)ax.alConsequent;
                        //Add another parameter in binds which makes use of the nomerge conditions
                        Hashtable binds = new Hashtable();
                        binds = b1.hStageProp(l1,l2,sAxNum); //send the axiom number along
                        if(!binds.isEmpty())
                        {
                            p.print(location, "\tMAIN: Binding is possible with Axiom: "+ax.sAxNum, bwOut);
                            Interpt iInterpt = new Interpt();
                            interptCounter++;
                            ArrayList alInterpts = iInterpt.createNewInterpt(currCounter,interptCounter,ax.sAxNum,binds);
                            for(int j=0;j<alInterpts.size();j++)
                            {
                                Interpt iNew = (Interpt)alInterpts.get(j);
                                alStack.add(iNew.iInterptNum);
                            }
                            //flag = true;
                            //p.printHashStringString(binds);
                        }
                    }
                    p.printAllInterptsHTML("tmp.html");
                }
            }
            else
            {
                alStack.clear();
            }
        }
    }
    /**
     * Opens the Scenario file, and stores the scenario as an Interpt.
     * 
     * @param fileName  Input filename which holds the Scenario in text format
     * @return  True if successful, False is unsuccessful
     */ 
    static boolean readScenario(String fileName)
    {
        Print p = new Print();
        p.print(location, fileName, bwOut);
        try
        {            
            File f = new File(fileName);
            if(!f.exists())
            { p.print(location, "MAIN:"+fileName+": File does not exist!", bwOut); System.exit(0); }
            else
            {  
                p.print(location, "MAIN: Reading Scenario File", bwOut);
                Main m = new Main();
                BufferedReader interptFileInput = new BufferedReader(new FileReader(fileName));
                int scNumber=0;
                String line1=new String();
                while ((line1=interptFileInput.readLine()) != null && !line1.equals(""))
                {
                    Interpt interpt = new Interpt();
                    boolean b = interpt.setInterpt(line1);
                    if(!b)
                    {
                        System.err.println("Error Line: "+line1);
                        System.exit(0);
                    }
                    Iterator it = interpt.alProps.iterator();
                    /*while(it.hasNext())
                    {
                        Prop p = (Prop)it.next();
                        if(Integer.parseInt(p.id) > iMaxID)
                        {
                            iMaxID = Integer.parseInt(p.id);
                        }
                    }*/
                    //hInterpt.put("0",interpt);
                    //alStack.add("0");
                }

                p.print(location, "\t.....done!", bwOut);
                interptFileInput.close();
            }
        }
        catch(IOException e)
        { return(false); }
        return(true);
    }
    /**
     * Opens the Axiom file and reads the Axioms and stores the Axioms in the 
     * Axiom format
     * 
     * @param fileName  Filename holding the Axioms in String format  
     * @return  True if no syntax error, False if there are syntax errors
     */    
    static boolean readAxiom(String fileName)
    {
        Print p = new Print();
        try
        {
            File f = new File(fileName);
            if(!f.exists())
            { System.err.println(fileName+": File does not exist!"); System.exit(0); }
            else
            {    
                p.print(location, "MAIN: Reading axioms file", bwOut);
                Main m = new Main();
                BufferedReader axiomsFileInput = new BufferedReader(new FileReader(fileName));
                String line1 = new String();
                int axiomCounter=1;
                while ((line1=axiomsFileInput.readLine()) != null)
                {
                    if((!line1.matches("//.*$"))&&(!line1.equals("\n"))&&(!line1.equals("")))
                    {
                        Axiom ax = new Axiom();
                        boolean b = ax.setAxiom(line1);
                        if(!b)
                        {
                            System.err.println("Error Line: "+line1);
                            System.exit(0);
                        }
                        //populateQSAxiom(ax,ax.sAxNum);
                        Main.axioms.put(ax.sAxNum, ax);
                        axiomCounter++;
                    }
                }
                p.print(location, "\t.....done!", bwOut);
                axiomsFileInput.close();
            }
            return(true);
        }
        catch(IOException e)
        {
            e.printStackTrace();
            return(false);
        }
    }
    /**
     * Creates a new Instance of the Main class
     */
    public Main()
    {
        ipid = 1;
    }
}
