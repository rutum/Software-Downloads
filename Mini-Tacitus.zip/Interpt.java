/*
 * Interpt.java
 *
 * Created on March 21, 2008, 2:54 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
import java.util.regex.*;


/**
 * This class contains all the functions and data structures for storing and
 * interpretation of a Scenario. It is named - Interpt, as a short form of 
 * interpretation. When an input Scenario is read, it is stored as an Interpt 
 * number 0. All other interpretations are derived from this base Interpt. 
 * 
 * <br><br>
 * <b>Format of a Scenario is:</b>
 * @author Rutu Mulkar-Mehta
 */

public class Interpt 
{
    /** Interpretation number */
    String iInterptNum;
    /** Cost of the Interpt */
    int icost;
    /** Parent number of the Interpt */
    String iParentID;
    /** Flag stating whether the Interpt is a duplicate */
    boolean bDuplicate;
    /** List of current Props in the Interpt */
    ArrayList alCurrProps;
    /** List of the Props in the Interpt that are currently being backchained on */
    ArrayList alProps;
    /** Axiom used to generate the current Interpt*/
    String sAxiomUsed;
    /** Integer that is appended to the current argument to make it an axiom introduced argument */
    static int ax = 1;
    /** List the set of arguments in the scenatio, which cannot be merged with
     * each other. This list is compiled by the preprocessor for each Scenario. 
     * The simple logic used is that anyh arguments which belong to the same 
     * Prop, cannot be merged with each other. */
    Hashtable hNoMerge;
    /** Fingerprint of the Interpt */
    Hashtable hFingerPrint;    
    /**Cumulative Axioms applied to all parents of current interpt*/
    Hashtable hAxiomsUsed;
    /**Set of constants in current interpt*/
    Hashtable hConstants;

    /**
     * Creates a new Interpretation from a parent Interpretation
     * 
     * @param iInterptNum   Parent Interpt number
     * @param iChildInterpt Child Interpt number
     * @param sAxNum    Axiom number used to generate the child Interpt
     * @param hBindings Contains 2 elements: Argument bindings between the 
     *        consequent of the Axiom and the Props in the parent Interpt, 
     *        Set of Props which are bound
     */
    ArrayList createNewInterpt(String iInterptNum,int iChildInterpt, String sAxNum, Hashtable hBindings)
    {
        Print pr = new Print();
        /* Get the selected props from hBindings */
        ArrayList alSelectedProps = (ArrayList)hBindings.get("props");

        /* Get the Axiom to Interpretation mapping from hBindings */
        Hashtable hMap = (Hashtable)hBindings.get("maps");        
        int maxDepth=0;
        //-------------------AXIOM-------------------------
        /* Get the selected axiom*/
        Axiom ax1 = (Axiom)Main.axioms.get(sAxNum);
        /* get LHS of selected Axiom*/
        ArrayList alLHS = (ArrayList)ax1.alAntecedent;
        ArrayList alRHS = (ArrayList)ax1.alConsequent;
        Hashtable hAxNM = (Hashtable)ax1.hNoMerge;
        this.hAxiomsUsed.put(sAxNum, "1");

        //------------PARENT INTERPRETATION----------------
        /* Get the parent interpretation*/
        Interpt iInterptParent = (Interpt)Main.hInterpt.get(iInterptNum);
        ArrayList alParentProps = (ArrayList)iInterptParent.alProps;        
        this.hAxiomsUsed.putAll(((Interpt)Main.hInterpt.get(iInterptNum)).hAxiomsUsed);
        this.hConstants.putAll(((Interpt)Main.hInterpt.get(iInterptNum)).hConstants);

        //------------CHILD INTERPRETATION-----------------
        /*set the interpretation number for the child */
        this.iInterptNum = Integer.toString(iChildInterpt);
        /* Copy all props from the parent props to the child props */
        int tmpi=0; 
        while(tmpi < alParentProps.size())
        {
            Prop p = new Prop();
            int i=0;
            if(!alSelectedProps.contains(((Prop)alParentProps.get(tmpi))))
            {
                p.copy((Prop)alParentProps.get(tmpi));
                this.alProps.add(p);
            }
            else
            {
                //copy this prop but set the cost to 0
                //this prop is mainly used when factoring with future sentences
                //This prop was already used for backchaining
                p.copy((Prop)alParentProps.get(tmpi));
                /* get max depth of the alSelectedProps, this plus 1 will be the
                 * depth of the new props that are introduced by the LHS of the axiom*/
                 if(p.depth <= maxDepth)
                 {
                     maxDepth=p.depth;
                 }
                /* Update the depth of all the props to max depth
                 so that they are not expanded further*/
                p.depth= Main.depth;
                p.cost=0;
                p.hAxioms.put(sAxNum, "1");
                this.alProps.add(p);
                pr.print(Main.location,"\tINTERPT: Backchained Props "+((Prop)alParentProps.get(tmpi)).getProp(), Main.bwOut);
            }
            tmpi++;
        }
        
        /*The depth of the antecedents must be one more than the depth 
         * of the first consequent of the axiom. The depth in the Axiom will always
         * by =0. Hence the depth must be found from the prop in the interpretation
         * */
        int i=0;         
        this.iParentID=iInterptNum;
        this.bDuplicate=false;
        this.alCurrProps.addAll(alSelectedProps);
        /*Update the noMerge arguments for the child, based on NM of the parent*/
        updateNoMerge((Hashtable)iInterptParent.hNoMerge);
        
        //this.hNoMerge.putAll((Hashtable)iInterptParent.hNoMerge);
        /* add the Antecedents from the axiom to the prop list of child interpretation
         *Change the arguments based on the mappings obtained from bind */
        i=0;
        Hashtable hAxArgs = new Hashtable();
        while(i < alLHS.size())
        {
            Prop p = new Prop(); 
            p.copy((Prop)alLHS.get(i));
            hAxArgs = p.atom.updateArgumentsAxiom(hMap,hAxArgs);
            /*set all depths to max depth to avoid looping of interpretations*/
            p.depth = maxDepth+1;
            p.id = "n"+Integer.toString(Main.ipid);
            Main.ipid++;
            p.costPropLHS(this.alCurrProps);
            this.alProps.add(p);
            i++;
        }
        /*Update no-merge arguments for the interpretation based on the NM of the Axiom and the binding arguments*/
        updateNoMerge(hAxNM,hAxArgs);
        
        this.sAxiomUsed= this.sAxiomUsed+sAxNum;
        this.setInterptCost();
        i=0;
        
        Factor f = new Factor();
        ArrayList alReturnVal = f.factorize(alProps, hNoMerge, hConstants);
        //foreach possible Interpt, create a new Interpt with these factorizations
        if(alReturnVal.size()>0)
        {
            pr.print(Main.location, "\tINTERPT: Factoring Possible...", Main.bwOut);
            ArrayList alInterpts = new ArrayList();
            for(int j=0;j<alReturnVal.size();j++)
            {
                pr.print(Main.location, "\tINTERPT: "+((ArrayMap)alReturnVal.get(j)).printArrayMap(), Main.bwOut);
                Interpt iNew = this.createFactoredInterpt((ArrayMap)alReturnVal.get(j),j);
                alInterpts.add(iNew);
            }
            for(int j=0;j<alInterpts.size();j++)
            {
                /* Creating a fingerprint of the Interpt and checking for duplicates */
                Interpt iNew = (Interpt)alInterpts.get(j);
                iNew.createFingerprint();
                int ihc = iNew.hFingerPrint.hashCode();
                if(Main.quickSearchInterpt.containsKey(ihc))
                {
                    //A similar interpt already exists, get all the Interpts in this category
                    //print("\tINTERPT: Checking for duplicate interpretations: ");
                    ArrayList alInterpt = (ArrayList)Main.quickSearchInterpt.get(ihc);
                    for(int ialCount=0;ialCount<alInterpt.size();ialCount++)
                    {
                        pr.print(Main.location, "\tINTERPT: Duplicate with Interpt: "+(((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).iInterptNum)+"? ", Main.bwOut);
                        /* if current interpt deep merges with this Interpt. mark the
                         * one with the higher cost to be a duplicate*/
                        Binding b = new Binding();
                        Hashtable bHash = b.BindArray(((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).alProps,(ArrayList)iNew.alProps);
                        if(!bHash.isEmpty())
                        {
                            pr.print(Main.location, " Yes!", Main.bwOut);
                            //it is proven at an argument level that the 2 interpretations are duplicates
                            if(((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).icost >= iNew.icost)
                            {
                                ((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).bDuplicate = true;
                                //remove this from quick search Interpt, and add the new
                                //interpt to it
                                ArrayList al1 = (ArrayList)Main.quickSearchInterpt.get(ihc);
                                al1.remove(alInterpt.get(ialCount));
                                al1.add(iNew.iInterptNum);
                                Main.quickSearchInterpt.put(ihc, al1);
                                Main.hInterpt.put(iNew.iInterptNum,iNew);
                            }
                            else
                            {
                                pr.print(Main.location, " No!", Main.bwOut);
                                iNew.bDuplicate = true;
                            }
                        }
                        else
                        {
                            ArrayList al2 = new ArrayList();
                            al2.add(iNew.iInterptNum);
                            Main.quickSearchInterpt.put(ihc, al2);
                            Main.hInterpt.put(iNew.iInterptNum,iNew);
                        }
                    }
                }
                else
                {
                    ArrayList al2 = new ArrayList();
                    al2.add(iNew.iInterptNum);
                    Main.quickSearchInterpt.put(ihc, al2);
                    Main.hInterpt.put(iNew.iInterptNum,iNew);
                }
            }
            return(alInterpts);
        }
        else
        {
            //Update the fingerprint and Interpt to HInterpt
            //and quickSearchInterpt
            this.createFingerprint();
            int ihc = this.hFingerPrint.hashCode();
            if(Main.quickSearchInterpt.containsKey(ihc))
            {
                //A similar interpt already exists, get all the Interpts in this category
                ArrayList alInterpt = (ArrayList)Main.quickSearchInterpt.get(ihc);
                for(int ialCount=0;ialCount<alInterpt.size();ialCount++)
                {
                    /* if current interpt deep merges with this Interpt. mark the
                     * one with the higher cost to be a duplicate*/
                    if(((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).icost > this.icost)
                    {
                        ((Interpt)Main.hInterpt.get((String)alInterpt.get(ialCount))).bDuplicate = true;
                        //remove this from quick search Interpt, and add the new
                        //interpt to it
                        ArrayList al1 = (ArrayList)Main.quickSearchInterpt.get(ihc);
                        al1.remove(alInterpt.get(ialCount));
                        al1.add(this.iInterptNum);
                        Main.quickSearchInterpt.put(ihc, al1);
                        Main.hInterpt.put(this.iInterptNum,this);
                    }
                    else { this.bDuplicate = true; }
                }
            }
            else
            {
                ArrayList al2 = new ArrayList();
                al2.add(this.iInterptNum);
                Main.quickSearchInterpt.put(ihc, al2);
                Main.hInterpt.put(this.iInterptNum,this);
            }
            ArrayList alTmp = new ArrayList();
            alTmp.add(this);
            return(alTmp);
        }
        //print("ok");
        //Print pr = new Print();
        //pr.printInterpt(this);
        //return(new ArrayList());
    }

    /**
     * Creates a new Interpretation from the ArrayMap of Props that can be
     * merged together.
     *
     * @param amList    ArrayMap of Props which can be merged with each other
     * @param num   Interpretation number of the current Interpt
     * @return  Interpt Structure
     */
    Interpt createFactoredInterpt(ArrayMap amList,int num)
    {
        Interpt iRet = new Interpt();
        ArrayList alPropsNew = new ArrayList();
        alPropsNew.addAll(this.alProps);
        iRet.iParentID = this.iParentID;
        //print("\tINTERPT: ");
        /* First deal with all the props in hIndexedProps, then look at the
         props in arrayMap, which were not already in hIndexedProps*/

        Hashtable alPropsDone = new Hashtable();
        Enumeration eIP = amList.hIndexedProps.keys();
        while(eIP.hasMoreElements())
        {
            Atom ap = (Atom)eIP.nextElement();
            ArrayList alp = (ArrayList)amList.hIndexedProps.get(ap);
            int cost=9999,depth=-2;
            String id = new String("");
            for(int i=1;i<alp.size();i++)
            {
                PropMap pmNew = (PropMap)amList.al.get((Integer)alp.get(i));
                if(alPropsNew.contains(pmNew.p1))
                {
                    //Pick the lowest cost and highest depth
                    if((pmNew.p1.cost <= pmNew.p2.cost) &&(pmNew.p1.cost <= cost))
                    { cost = pmNew.p1.cost; }
                    if((pmNew.p2.cost <= pmNew.p1.cost) &&(pmNew.p2.cost <= cost))
                    { cost = pmNew.p2.cost; }
                    if((pmNew.p2.depth >= pmNew.p1.depth) && (pmNew.p2.depth >= depth))
                    { depth = pmNew.p2.depth; }
                    if((pmNew.p1.depth >= pmNew.p2.depth) && (pmNew.p1.depth >= depth))
                    { depth = pmNew.p1.depth; }
                    if(id.equals(""))
                    { id = pmNew.p1.id+"."+pmNew.p2.id; }
                    else
                    { id = id+"."+pmNew.p1.id+"."+pmNew.p2.id; }
                    alPropsNew.remove(pmNew.p1);
                    alPropsNew.remove(pmNew.p2);
                    alPropsDone.put(pmNew.p1,1);
                    alPropsDone.put(pmNew.p2,1);
                }
            }
            if((cost != 9999)&&(depth != -2))
            {
                Prop pNew = new Prop();
                pNew.atom.copy(ap);
                pNew.cost=cost;
                pNew.depth=depth;
                pNew.id=id+"."+(String)alp.get(0);
                alPropsNew.add(pNew);
            }
            
        }
        for(int i=0;i<amList.al.size();i++)
        {
            PropMap p = (PropMap)amList.al.get(i);
            if(!(alPropsDone.containsKey((Prop)p.p1))&&!(alPropsDone.containsKey((Prop)p.p2)))
            {
                //print("\tINTERPT: Before "+alPropsNew.size());
                if(alPropsNew.contains(p.p1))
                {
                    //print("\tINTERPT: Removing "+p.p1.getProp());
                    alPropsNew.remove(p.p1);
                    //print("\tINTERPT: then "+alPropsNew.size());
                }
                else
                {
                    System.err.println("\tINTERPT: Could not remove "+p.p1.getProp());
                    System.exit(0);
                }
                if(alPropsNew.contains(p.p2))
                {
                    //print("\tINTERPT: Removing "+p.p2.getProp());
                    alPropsNew.remove(p.p2);
                }
                else
                {
                    System.err.println("\tINTERPT: Could not remove "+p.p2.getProp());
                    System.exit(0);
                }
                //print("\tINTERPT: After "+alPropsNew.size());
                Prop pNew = new Prop(); pNew.atom.copy(p.p1.atom);
                //print(pNew.getProp());
                //Update arguments
                pNew.atom.updateArgumentsInterpt(p.hMaps);
                //print(pNew.getProp());
                //Update cost
                if(p.p1.cost <= p.p2.cost){pNew.cost = p.p1.cost;}
                else{pNew.cost = p.p2.cost;}
                //Update depth
                if(p.p1.depth >= p.p2.depth){pNew.depth = p.p1.depth;}
                else{pNew.depth = p.p2.depth;}
                pNew.id = p.p1.id+"."+p.p2.id;
                pNew.hAxioms.putAll(p.p1.hAxioms);
                pNew.hAxioms.putAll(p.p2.hAxioms);
                alPropsNew.add(pNew);
            }
        }
        ArrayList alPropsNew2 = new ArrayList();
        for(int i=0;i<alPropsNew.size();i++)
        {
            Prop p = (Prop)alPropsNew.get(i);
            Prop pNew = new Prop();
            pNew.copy(p);
            //print(pNew.getProp());
            pNew.atom.updateArgumentsInterpt(amList.hMaps);
            alPropsNew2.add(pNew);
        }
        iRet.alProps.clear();
        iRet.alProps.addAll(alPropsNew2);
        iRet.setInterptCost();
        iRet.iInterptNum = this.iInterptNum+"f"+Integer.toString(num);
        iRet.alCurrProps.addAll(this.alCurrProps);
        iRet.sAxiomUsed= this.sAxiomUsed;
        iRet.hAxiomsUsed.putAll(this.hAxiomsUsed);
        iRet.hNoMerge.putAll(this.hNoMerge);
        iRet.hNoMerge=iRet.updateNoMerge(iRet.hNoMerge, amList.hMaps);
        iRet.hConstants.putAll(this.hConstants);
        return(iRet);
    }

    /**
     * Updates noMerge when factoring is performed and arguments are merged
     * @param hNoMerge
     * @param hMaps
     * @return
     */
    Hashtable updateNoMerge(Hashtable hNoMerge, Hashtable hMaps)
    {
        Enumeration e = hNoMerge.keys();
        while(e.hasMoreElements())
        {
            String key = (String)e.nextElement();
            Hashtable hVals = (Hashtable)hNoMerge.get(key);
            if(hMaps.containsKey(key))
            {
                Enumeration ev = hVals.keys();
                while(ev.hasMoreElements())
                {
                    String k1 = (String)ev.nextElement();
                    if(hMaps.containsKey(k1))
                    {
                        hVals.remove(k1);
                        hVals.put((String)hMaps.get(k1), 1);
                    }
                }
                if(hNoMerge.containsKey((String)hMaps.get(key)))
                {
                    Hashtable hTmp = (Hashtable)hNoMerge.get((String)hMaps.get(key));
                    hTmp.putAll(hVals);
                }
                else
                {
                    hNoMerge.put((String)hMaps.get(key), hVals);
                    hNoMerge.remove(key);
                }
            }
            else
            {
                Enumeration ev = hVals.keys();
                while(ev.hasMoreElements())
                {
                    String k1 = (String)ev.nextElement();
                    if(hMaps.containsKey(k1))
                    {
                        hVals.remove(k1);
                        hVals.put((String)hMaps.get(k1), 1);
                    }
                }
                hNoMerge.put(key, hVals);
            }
        }
        return(hNoMerge);
    }

    /**
     * Propagates noMerge from parent to child
     * @param hParentNM
     */
    void updateNoMerge(Hashtable hParentNM)
    {
        Enumeration e = hParentNM.keys();
        /* For all the keys of the parent NoMerge */
        while(e.hasMoreElements())
        {
            String key = (String)e.nextElement();
            Enumeration e1 = ((Hashtable)hParentNM.get(key)).keys();
            /* For all the keys of the value of the parent NoMerge */
            while(e1.hasMoreElements())
            {
                String val = (String)e1.nextElement();
                /* Now we have a key-value pair of no-merge arguments*/
                if(this.hNoMerge.containsKey(key))
                {
                    /*if the child no-Merge already contains this key, add the value to it*/
                    Hashtable h = (Hashtable)hNoMerge.get(key);
                    if((!h.containsKey(val)) && (!val.equals(key)))
                    {
                        h.put(val, "1");
                        hNoMerge.put(key, h);
                    }
                }
                else
                {
                    /*the child no-merge does not contain this key, add the key and value to it*/
                    if(!val.equals(key))
                    {
                        Hashtable h = new Hashtable();
                        h.put(val,"1");
                        this.hNoMerge.put(key, h);
                    }
                }
            }
        }
    }

     /**
     * Calculates the total cost of the Interpt as the sum of the costs of all 
     * the individual Props within it. 
     */
    void setInterptCost()
    {
        int i=0,cost=0;        
        while(i<this.alProps.size())
        {
            Prop p = (Prop)alProps.get(i);
            cost=cost + p.cost;
            i++;
        }
        this.icost=cost;
    }
    /**
     * Gets the Interpt/Scenario in String format, and converts it into the
     * Interpt object
     * 
     * @param line  String representation of the Interpt
     * @return  True if there is no syntax error, False if there is a syntax 
     * error
     */
    boolean setInterpt(String line)
    {
        Print p = new Print();
        Pattern pattern = Pattern.compile("\\d*\\](.*)\\|(.*)|(.*)");
        Matcher matcher = pattern.matcher(line);
        boolean bool = matcher.matches();
        if(!bool) 
        { 
            System.err.println("INTERPT: Illegal interpretation format."); return(false);
        }
        Pattern pattern1 = Pattern.compile("\\]|\\|");
        String[] items = pattern1.split(line);
        
        String iNum = new String(); String iProps = new String(); 
        String iNM = new String(); String sConstants = new String();
        iNum = items[0]; 
        iProps = items[1]; 
        iNM = items[2];
        sConstants = items[3];
        
        /*Set the props*/                    
        Pattern props = Pattern.compile(" & ");
        String[] props1 = props.split(iProps);            
        for(int i=0;i<props1.length;i++)
        {
            Prop p1 = new Prop();
            boolean b = p1.setPropInterpt(props1[i]);
            if(!b){System.err.println("INTERPT: Illegal Proposition format: "+props1[i]); return(false); }
            this.alProps.add(p1);
        }        
        /*set the no-merge variables*/
        if(!iNM.equals(" "))
        {
            Pattern nm = Pattern.compile(",");
            String[] unit = nm.split(iNM);
            for(int i=0;i<unit.length;i++)
            {
                Pattern singleUnit = Pattern.compile("-");
                String[] args = singleUnit.split(unit[i]);
                //print(args[0]+"   "+args[1]);
                if(this.hNoMerge.containsKey(args[0]))
                {
                    Hashtable h = (Hashtable)this.hNoMerge.get(args[0]);
                    h.put(args[1],1); this.hNoMerge.put(args[0],h);
                }
                else
                {
                    Hashtable h = new Hashtable();
                    if(args.length>1)
                    { h.put(args[1],1); this.hNoMerge.put(args[0],h); }
                }
                if(this.hNoMerge.containsKey(args[1]))
                {
                    Hashtable h = (Hashtable)this.hNoMerge.get(args[1]);
                    h.put(args[0],1); this.hNoMerge.put(args[1],h);
                }
                else
                {
                    Hashtable h = new Hashtable();
                    if(args.length>1)
                    { h.put(args[0],1); this.hNoMerge.put(args[1],h); }
                }
            }
        }               
        /*set the cost*/
        this.setInterptCost();

        /*set constants*/
        if(!sConstants.equals(" "))
        {
            Pattern con = Pattern.compile(",");
            String[] constants = con.split(sConstants);
            for(int i=0;i<constants.length;i++)
            {
                String sc = (String)constants[i];
                this.hConstants.put(sc, "1");
            }
        }
        this.iParentID="-1";
        this.sAxiomUsed="none";
        this.alCurrProps.add(new Prop());
        this.createFingerprint();
        Factor f = new Factor();

        ArrayList alFactor = f.factorize(this.alProps, this.hNoMerge, this.hConstants);
        ArrayList alInterpts = new ArrayList();
        Main.hInterpt.put("0", this);
        if(alFactor.size()>0)
        {
            p.print(Main.location, "\tINTERPT: Factoring Possible...", Main.bwOut);
            int ctr1=1;
            for(int j=0;j<alFactor.size();j++)
            {
                p.print(Main.location, "\tINTERPT: "+((ArrayMap)alFactor.get(j)).printArrayMap(), Main.bwOut);
                Interpt iNew = this.createFactoredInterpt((ArrayMap)alFactor.get(j),j);
                alInterpts.add(iNew);
                iNew.createFingerprint();
                //String ctr = new String("0f"+Integer.toString(ctr1));
                Main.hInterpt.put(iNew.iInterptNum,iNew);
                Main.alStack.add(iNew.iInterptNum);
                ctr1++;
                ArrayList alTmp = new ArrayList();
                alTmp.add((String)iNew.iInterptNum);
                Main.quickSearchInterpt.put(iNew.hFingerPrint.hashCode(),alTmp);
            }
        }
        else
        {
            this.createFingerprint();
            Main.hInterpt.put("0",this);
            Main.alStack.add("0");
            ArrayList alTmp = new ArrayList();
            alTmp.add((String)this.iInterptNum);
            Main.quickSearchInterpt.put(this.hFingerPrint.hashCode(),this);
        }
        return(true);
    }
    
    /**
     * Creates a shallow fingerprint of the Interpt, based on the number of times
     * a predicate is repeated in a Intept. This is for shortlisting the Interpts
     * that might be duplicates so that deeper evaluation can be performed for them
     */
    void createFingerprint()
    {
        for(int i=0;i<this.alProps.size();i++)
        {
            Prop p = (Prop)this.alProps.get(i);
            String sPredicate = (String)p.atom.pred;
            if(this.hFingerPrint.containsKey(sPredicate))
            {
                String val = (String)this.hFingerPrint.get(sPredicate);
                int ival = Integer.parseInt(val);
                ival++;
                this.hFingerPrint.put(sPredicate, Integer.toString(ival));
            }
            else
            {
                this.hFingerPrint.put((String)p.atom.pred, "1");
            }
        }
    }
    /** Creates a new Interpt and assigns all the Interpt values, default values */
    public Interpt() 
    {
        iInterptNum = new String("0");
        icost = 0;
        iParentID = "0";
        bDuplicate = false;
        alCurrProps = new ArrayList();
        alProps = new ArrayList();
        sAxiomUsed = new String();   
        hNoMerge = new Hashtable();
        hFingerPrint = new Hashtable();
        hAxiomsUsed = new Hashtable();
        hConstants = new Hashtable();
    }
}
