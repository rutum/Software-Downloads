 package minitacitus;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Enumeration;
import java.util.Iterator;
/**
 * Factors an Interpt generated. We want to get a final Interpt
 * which has the lowest cost. Various different props can be factored,
 * best solution is the one which has the lowest cost when factoring
 * takes place. As a result the longest list of Props that can be factored
 * must be selected, such that they do not violate the argument merging
 * constraints of each other. <br>
 * <br>
 * @author Rutu Mulkar-Mehta
 */
public class Factor
{
    /** Hashtable containing the predicate name as the key, and an ArrayList
     * of Props as the value. The list of Props all have the same predicate
     * name as the corresponding key. */
    Hashtable hIndexedPred;
    /** Hashtable indexed by the predicate name and contains the value of an
     * ArrayList, where each element in the ArrayList is a PropMap. */
    Hashtable hMergPreds;
    /** Factorizes the Interpt and selects the best solution and returns it to
     * the calling method
     * @param alProps   Set of Props that need to be Factorized
     * @param hNoMerge  Hash or arguments that cannot be merged with each other
     * @param hConstants    Hash of Constants
     * @return  ArrayList of Props which make the final most suitable interpt  */
    ArrayList factorize(ArrayList alProps, Hashtable hNoMerge, Hashtable hConstants)
    {
        Binding b = new Binding();
        Print p = new Print();
        /*Index the Props by their Pred name and determine which Props can be
        merged with each other based on the NoMerge and Constants conditions */
        hIndexedPred = b.indexByPred(alProps);
        ArrayList alPropMaps1 = new ArrayList();
        /*Populate the hMergPreds data structure */
        this.mergeablePreds(hNoMerge, hConstants);
        Enumeration e = this.hMergPreds.keys();
        while(e.hasMoreElements())
        {
            ArrayList al = (ArrayList)hMergPreds.get(e.nextElement());
            alPropMaps1.addAll(al);
        }
        /*Get all the combinations of PropMaps that can be merged together*/
        ArrayList alCombinations = this.getCombinations(alPropMaps1, new Hashtable(), hNoMerge);
        ArrayList alReturn = new ArrayList();
        /* Find the largest ArrayList returned by the conbination generator */
        int iLargestAL =0;
        for(int i=0;i<alCombinations.size();i++)
        {
            //print the combination arrayMap
            //p.print("\tINTERPT: "+((ArrayMap)(alCombinations.get(i))).printArrayMap());
            if(((ArrayMap)alCombinations.get(i)).al.size() > iLargestAL)
            {
                iLargestAL = ((ArrayMap)alCombinations.get(i)).al.size();
                alReturn.removeAll(alReturn);
                alReturn.add((ArrayMap)alCombinations.get(i));
            }
            else if(((ArrayMap)alCombinations.get(i)).al.size() == iLargestAL)
            { alReturn.add((ArrayMap)alCombinations.get(i)); }
        }        
        /* Shortlisting the List which has fewest number of argument merges -
         * Preference is given to the list of arguments which all involve merging
         * the same argument pairs. */
        ArrayList alReturn2 = new ArrayList();
        int iMap=99; int index =0;
        for(int i=0;i<alReturn.size();i++)
        {
            ArrayMap am = (ArrayMap)alReturn.get(i);
            if(am.hMaps.size() < iMap)
            {
                iMap = am.hMaps.size();
                alReturn2.clear();
                alReturn2.add(am);
            }
            else
            {
                if(am.hMaps.size() == iMap)
                { alReturn2.add(am); }
            }
        }
        p.print(Main.location, "\tFACTOR: got mergeable props, returning to Interpt", Main.bwOut);

        /** populate hIndexedProps */
        Iterator iAlret2 = alReturn2.iterator();
        while(iAlret2.hasNext())
        {
            ArrayMap am2 = (ArrayMap)iAlret2.next();
            for(int i=0;i<am2.al.size();i++)
            {
                PropMap pm1 = (PropMap)am2.al.get(i);
                if(am2.hIndexedProps.containsKey(pm1.p1.atom))
                {
                    ArrayList altmp = (ArrayList)am2.hIndexedProps.get(pm1.p1.atom);
                    altmp.add(i);
                    am2.hIndexedProps.put(pm1.p1.atom, altmp);
                }
                else if(am2.hIndexedProps.containsKey(pm1.p2.atom))
                {
                    ArrayList altmp = (ArrayList)am2.hIndexedProps.get(pm1.p2.atom);
                    altmp.add(i);
                    am2.hIndexedProps.put(pm1.p2.atom, altmp);
                }
                else
                {
                    ArrayList altmp = new ArrayList();
                    altmp.add(pm1.p1.id);
                    altmp.add(i);
                    am2.hIndexedProps.put(pm1.p1.atom, altmp);
                    am2.hIndexedProps.put(pm1.p2.atom, altmp);
                }
            }
            /** Remove from hIndexedProps, all entries whose value size is less than or equal to 2 */
            Enumeration e5 = am2.hIndexedProps.keys();
            while(e5.hasMoreElements())
            {
                Atom aCurr = (Atom)e5.nextElement();
                ArrayList al5 = (ArrayList)am2.hIndexedProps.get(aCurr);
                if(al5.size() <= 2)
                {
                    am2.hIndexedProps.remove(aCurr);
                }
            }
        }

        return(alReturn2);
    }

    /**
     * Determines if argument hash newHash of mergeable arguments is compatible
     * with already existing hash oldHash of mergeable arguments
     *
     * @param newHash    new hashtable being tested
     * @param oldHash    Already existing hashtable
     * @return  true if compatible, false otherwise
     */
    boolean isArgCompatible(Hashtable newHash, Hashtable oldHash, Hashtable hNM)
    {
        Enumeration e = newHash.keys();
        while(e.hasMoreElements())
        {
            String key = (String)e.nextElement();
            String val = (String)newHash.get(key);
                       
            /** -----------------OLD CODE------------------
             * Merging is not possible if the old hash already contains the
             * key of the new hash, but the value is different from the value
             * of the new hash*/
            
            if((oldHash.containsKey(key))&&(!((String)oldHash.get(key)).equals(val)))
            {
                return(false);
            }
            if((oldHash.containsKey(val))&&(!((String)oldHash.get(val)).equals(key)))
            {
                return(false);
            }
            if(oldHash.containsValue(key))
            {
              Enumeration e1 = oldHash.keys();
              while(e1.hasMoreElements())
              {
                  String k1 = (String)e1.nextElement();
                  String v1 = (String)oldHash.get(k1);
                  if((v1.equals(key))&&(!k1.equals(val)))
                  {
                      return(false);
                  }
              }
            }
            if(oldHash.containsValue(val))
            {
              Enumeration e1 = oldHash.keys();
              while(e1.hasMoreElements())
              {
                  String k1 = (String)e1.nextElement();
                  String v1 = (String)oldHash.get(k1);
                  if((v1.equals(val))&&(!k1.equals(key)))
                  {
                      return(false);
                  }
              }
            }
        }
        return(true);
    }

    /**
     * This is a recursive function to get all the combinations of Props
     * that can be factored together without violating each others
     * constraints. <br><br>
     *
     * @param alPrp ArrayList of PropMaps that can be merged
     * @param hmaps Hashtable of already existing Maps
     * @return  ArrayList
     */
    ArrayList getCombinations(ArrayList alPrp, Hashtable hmaps, Hashtable hNM)
    {
        if(alPrp.size()>1)
        {
            PropMap p = (PropMap)alPrp.get(0);
            alPrp.remove(0);
            //p.print("\t\tCOMBINATIONS: removing "+p.printPropMap());
            ArrayList alSubset = getCombinations(alPrp,hmaps,hNM);
            ArrayList alNew = new ArrayList();
            //foreach bucket in the alSubset, if the current PropMap is compatible,
            //then add it to the list.
            for(int i=0;i<alSubset.size();i++)
            {
                ArrayMap aRet = (ArrayMap)alSubset.get(i);
                //p.print("\t\tCOMBINATIONS: testing "+ p.printPropMap()+" with "+aRet.printArrayMap());
                if(p.p1.atom.pred.equals("energy-nn'"))
                {
                   // p.print("checkpoint");
                }
                boolean val = isArgCompatible(p.hMaps,aRet.hMaps, hNM);
                if(val == true)
                {
                    ArrayMap aNew = new ArrayMap();
                    aNew.al.addAll(aRet.al);
                    aNew.al.add(p);
                    aNew.hMaps.putAll(aRet.hMaps);
                    aNew.hMaps.putAll(p.hMaps);
                    alNew.add(aNew);
                }
            }
            alSubset.addAll(alNew);
            return(alSubset);
        }
        else
        {
            if(!alPrp.isEmpty())
            {
                PropMap p = (PropMap)alPrp.get(0);
                //p.print("\t\tCOMBINATIONS: Seed PropMap "+p.printPropMap());
                ArrayMap arMap = new ArrayMap();
                arMap.al.add(p);
                arMap.hMaps.putAll(p.hMaps);
                ArrayList alRet = new ArrayList();
                alRet.add(arMap); alRet.add(new ArrayMap());
                return(alRet);
            }
            else
            {
                return(new ArrayList());
            }
        }
    }

    /**
     * Lists the Props in a Pred index that can be merged with each other
     *
     * @param hNoMerge  Hash of arguments that cannot me merged with each other
     * @param hCon  Hash of Constants in the Interpt
     */
    void mergeablePreds(Hashtable hNoMerge, Hashtable hCon)
    {
        Enumeration e = hIndexedPred.keys();
        while(e.hasMoreElements())
        {
            String pred = (String)e.nextElement();
            ArrayList alPreds = (ArrayList)hIndexedPred.get(pred);
            for(int i=0;i<alPreds.size();i++)
            {
                for(int j=i+1;j<alPreds.size();j++)
                {
                    Prop p1 = (Prop)alPreds.get(i);
                    Prop p2 = (Prop)alPreds.get(j);
                    //make a new function in atom - mergeAtom that will merge
                    //2 atoms. This must be separate from the one used in Bind
                    //which is primarily used for Axiom binding
                    ReturnStructure r = p1.atom.mergeAtom(p2.atom, hNoMerge, hCon);
                    if(r.possible == true)
                    {
                        if(hMergPreds.containsKey(pred))
                        {
                            ArrayList al = (ArrayList)hMergPreds.get(pred);
                            PropMap pm1  = new PropMap();
                            pm1.p1=p1; pm1.p2=p2;
                            pm1.hMaps.putAll(r.hMappings);
                            al.add(pm1);
                            hMergPreds.put(pred, al);
                        }
                        else
                        {
                            ArrayList al = new ArrayList();
                            PropMap pm1 = new PropMap();
                            pm1.p1 = p1; pm1.p2=p2;
                            pm1.hMaps.putAll(r.hMappings);
                            al.add(pm1);
                            hMergPreds.put(pred, al);
                        }
                    }
                }
            }
        }
    }
    /**
     * Creates a new instance of the Factor class
     */
    public Factor()
    {
        hMergPreds = new Hashtable();
        hIndexedPred = new Hashtable();
    }
}
