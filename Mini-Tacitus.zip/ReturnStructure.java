/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
/**
 * Represents a structure for returning values from a function, whose return
 * value requires a true/false value as well as a hashtable.
 *
 * @author Rutu Mulkar-Mehta
 */
public class ReturnStructure 
{
    boolean possible;
    Hashtable hMappings;
    public class AxiomsMapping
    {
        Hashtable hAxMap;
        public AxiomsMapping()
        {
            hAxMap = new Hashtable();
        }
    }
    public class InterptMapping
    {
        Hashtable hInMap;
        public InterptMapping()
        {
            hInMap = new Hashtable();
        }
    }
    /**
     * Creates a new instance of ReturnStructure
     */
    public ReturnStructure()
    {
        possible=false;
        hMappings = new Hashtable();
    }
    
}
