/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.Hashtable;
import java.util.ArrayList;
import java.util.Iterator;
/**
 *ArrayList containing individual elements as PropMaps, and a Hashtable
 * that contains te cumulative argument merges from each of the individual
 * PropMaps
 * @author Rutu
 */
public class ArrayMap
{
    /** ArrayList containing individual elements as PropMaps */
    ArrayList al;
    /** hashtable indexed by the props, and value is the list of indices of
     * props being merged with this prop */
    Hashtable hIndexedProps;
    /** Hashtable containing cumulative argument mappings from all the
     * individual PropMaps */
    Hashtable hMaps;
    /**
     * Prints the string equivalent of the ArrayMap
     * @return String equivalent of the ArrayMap
     */
    String printArrayMap()
    {
        Iterator i = al.iterator();
        String sReturn = new String();
        while(i.hasNext())
        {
            PropMap p = (PropMap)i.next();
            sReturn = sReturn+" "+p.printPropMap();
        }
        return(sReturn);
    }
    /**
     * Creates a new instance of the ArrayMap
     */
    public ArrayMap()
    {
        al = new ArrayList();
        hMaps = new Hashtable();
        hIndexedProps = new Hashtable();
    }
}