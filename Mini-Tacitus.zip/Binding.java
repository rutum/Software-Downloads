package minitacitus;
import java.util.*;
/**
 * The purpose of this class is to try and bind sets of propositions from
 * Axioms to the propositions mentioned in the Scenario. There is support
 * to backtrack to previous stages. 
 * 
 * @author Rutu Mulkar-Mehta 
 */
public class Binding 
{ 
/**
 * The purpose of this class is to maintain all the information required
 * with respect to a specific stage of the merging process.
 *
 * @author Rutu Mulkar-Mehta
 */
private class Stage
{
    /** Axiom Proposition */
    Prop PropV1;
    /** Scenario Proposition */
    Prop PropV2;
    /** If the scenario has more than 1 proposition with the same predicate
     * name, all the propositions are tried one after the other.
     * The proposition being tried with a specific predicate name is
     * the v2Counter */
    int v2Counter;
    /** Predicate name of the current proposition being bound/merged */
    String stagePred;
    /** Hashtable representing the argument bindings of all the previous
     * propositions already bound */
    Hashtable BindingTillNow;
    /** This represents the total number of propositions to be bound. i.e.
     * total number of propositions on the RHS of the axiom being considered. */
    int istageNum;
    /** Creates a new instance of the Stage class */
    public Stage()
    {
        PropV1 = new Prop();
        PropV2 = new Prop();
        BindingTillNow = new Hashtable();
        istageNum = 0 ;
        v2Counter =0;
        stagePred ="";
    }
}
/**
* Used inorder to backtrack to a previous binding stage if no match
* occurs in the current stage. A stage is the number of propositions
* that are already bound right now. The set of untried matching 
* possibilities are stored as an instance of the Backtrack class in an 
* Arraylist. 
*/
private class BackTrack
{
    /** Keeps track of the stage number  */
    int stageID;
   /** The propositions tried in v2 at a specific stage.
     * E.g. if v2 contains 3 propositions: happy'(e1,x1):1, happy'(e2,x2):2
     * and happy'(e3,x3):3, then the v2 counter represents the backtracking
     * point where the proposition can be tried for binding with the prop in
     * the Axiom. */
    int v2Counter;
    /** Creates a new instance of the class BackTrack */
    public BackTrack()
    {
        stageID =0;
        v2Counter =0;
    }
}
/** This contains the pred = id mappings for the consequent of the Axiom*/
Hashtable hV1PredProp;
/** This contains the pred = id mappings for the propositions of the Scenatio */
Hashtable hV2PredProp;
/** This contains the pred = stageID mapping */
Hashtable hStagePred;
/** This maintains all the bindings over all stages*/
Hashtable hBindings;
/** Stack holding the previous backtracking points */
ArrayList backTrack;
/** This function checks whether the consequent of the axioms selected
* (v1) is able to match any subset of propositions in the current 
* scenario (v2).
* 
* @param v1    propositions from Axioms 
* @param v2    propositions from Scenario
* @return   return a hashtable with 3 structures
* a true/false value whether merging is possible
* a list of props that are being merged
* hashtable of arguments being merged
* If there is a match it returns a Hashtable containing : 
*          <ul>
*           <li>A set of merged propositions
*           <li>A mapping of arguments from which the merged props are derived
*          </ul>
*           If there is no match, an empty Hashtable is returned. */
Hashtable BindArray(ArrayList v1, ArrayList v2)
{
    Print p = new Print();
    ArrayList combined = new ArrayList();
    hV1PredProp = indexByPred(v1);
    hV2PredProp = indexByPred(v2);
    hStagePred=getPockets();
    int iTotalBindings = v1.size();

    //Initialize stage 0 in the bindings table
    Stage s = new Stage();
    s.istageNum=0;
    hBindings = new Hashtable();
    hBindings.put(0,s);
    int stageCounter=1;
    int prevStageCounter=0;
    boolean backFlag = false;
    backTrack = new ArrayList();
    while(stageCounter<=iTotalBindings)
    {
        Stage st0 = new Stage();
        if(stageCounter == (prevStageCounter + 1))
        {
            //We have progressed to the next stage. Add all previous bindings
            //to this stage
            if(backFlag != true)
            {
                /*This new stage is going to be an extension of the old stage.
                 * add all the details to the new stage*/
                st0 = new Stage();
                st0.istageNum=stageCounter;
                Stage stOld = (Stage)hBindings.get(prevStageCounter);
                st0.BindingTillNow.putAll(stOld.BindingTillNow);
                st0.stagePred = (String)((Prop)hStagePred.get(stageCounter)).atom.pred;
                st0.PropV1 = (Prop)((ArrayList)hV1PredProp.get(st0.stagePred)).get(0);
                if(hV2PredProp.containsKey(st0.stagePred))
                {st0.PropV2 = (Prop)((ArrayList)hV2PredProp.get(st0.stagePred)).get(st0.v2Counter);}
                else
                { return(new Hashtable()); }

                /*backtracking segment, if the interpretation has more than one possible propositions
                 * for the same predicate name, add a backtracking stage for the next proposition to be
                 * tried*/
                if((((ArrayList)hV2PredProp.get(st0.stagePred)).size() > 1)&&(st0.v2Counter < ((ArrayList)hV2PredProp.get(st0.stagePred)).size()))
                {
                    BackTrack b = new BackTrack();
                    b.stageID=stageCounter;
                    b.v2Counter=st0.v2Counter+1;
                    backTrack.add(b);
                }
            }
            else if(backFlag == true)
            {
                BackTrack bt = (BackTrack)backTrack.get(backTrack.size()-1);
                backTrack.remove(backTrack.size()-1);
                st0 = (Stage)hBindings.get(bt.stageID);
                st0.v2Counter=bt.v2Counter;
                st0.PropV2= (Prop)((ArrayList)hV2PredProp.get(st0.stagePred)).get(st0.v2Counter);
                backFlag = false;
                //p.print("\tBINDING: Backtracking to "+st0.v2Counter);
                int V2size = ((ArrayList)hV2PredProp.get(st0.stagePred)).size();
                if((st0.v2Counter + 1) < V2size)
                {
                    BackTrack b = new BackTrack();
                    b.stageID=stageCounter;
                    b.v2Counter=st0.v2Counter+1;
                    backTrack.add(b);
                }
            }
            hBindings.put(stageCounter,st0);
        }
        ArrayList v2Pred = (ArrayList)hV2PredProp.get(st0.stagePred);
        //PrintBindingStatus(st1.stagePred,stageCounter,p11,p12);
        ReturnStructure r = st0.PropV1.bindProp(st0.PropV2,st0.BindingTillNow,new Hashtable());
        //p.print("Props selected: "+p11.atom.getAtom()+" "+p12.atom.getAtom());
        if(r.possible == true)
        {
            st0.BindingTillNow.putAll(r.hMappings);
            hBindings.put(stageCounter, st0);
            stageCounter++;
            prevStageCounter= stageCounter-1;
            //p.print("\n"+p11.atom.getAtom()+" can be merged with "+p12.atom.getAtom());
        }
        else if(r.possible == false)
        {
            if(backTrack.isEmpty())
            { return(new Hashtable()); }
            else
            { backFlag = true; }
        }
    }
    //get all the v2 props that were selected
    ArrayList merged = new ArrayList();
    int size = hBindings.size();
    int isize =1;
    while(isize < size)
    {
        Stage val = (Stage)hBindings.get(isize);
        merged.add(val.PropV2);
        isize++;
    }
    Hashtable returnHash = new Hashtable();
    returnHash.put("props",merged);
    returnHash.put("maps",((Stage)hBindings.get(iTotalBindings)).BindingTillNow);
    return(returnHash);
}

Hashtable hStageProp(ArrayList v1, ArrayList v2, String sAxNum)
{
    Print p = new Print();
    ArrayList combined = new ArrayList();
    hV1PredProp = indexByPred(v1);
    hV2PredProp = indexByPred(v2);
    hStagePred=getPockets();
    int iTotalBindings = hStagePred.size();
    //Initialize stage 0 in the bindings table
    Stage s = new Stage();
    s.istageNum=0;
    hBindings = new Hashtable();
    hBindings.put(0,s);
    int stageCounter=1;
    int prevStageCounter=0;
    boolean backFlag = false;
    backTrack = new ArrayList();
    while(stageCounter<=iTotalBindings)
    {
        Stage st0 = new Stage();
        if(stageCounter == (prevStageCounter + 1))
        {
            //We have progressed to the next stage. Add all previous bindings
            //to this stage
            if(backFlag != true)
            {
                /*This new stage is going to be an extension of the old stage.
                 * add all the details to the new stage*/
                st0 = new Stage();
                st0.istageNum=stageCounter;
                Stage stOld = (Stage)hBindings.get(prevStageCounter);
                st0.BindingTillNow.putAll(stOld.BindingTillNow);
                st0.PropV1 = (Prop)hStagePred.get(stageCounter);
                st0.stagePred = (String)(((Prop)hStagePred.get(stageCounter)).atom.pred);

                if(hV2PredProp.containsKey(st0.stagePred))
                { st0.PropV2 = (Prop)((ArrayList)hV2PredProp.get(st0.stagePred)).get(st0.v2Counter);}
                else
                { return(new Hashtable()); }

                /*backtracking segment, if the interpretation has more than one possible propositions
                 * for the same predicate name, add a backtracking stage for the next proposition to be
                 * tried*/
                if((((ArrayList)hV2PredProp.get(st0.stagePred)).size() > 1)&&(st0.v2Counter < ((ArrayList)hV2PredProp.get(st0.stagePred)).size()))
                {
                    BackTrack b = new BackTrack();
                    b.stageID=stageCounter;
                    b.v2Counter=st0.v2Counter+1;
                    backTrack.add(b);
                }
            }
            else if(backFlag == true)
            {
                BackTrack bt = (BackTrack)backTrack.get(backTrack.size()-1);
                backTrack.remove(backTrack.size()-1);
                st0 = (Stage)hBindings.get(bt.stageID);
                st0.v2Counter=bt.v2Counter;
                st0.PropV2= (Prop)((ArrayList)hV2PredProp.get(st0.stagePred)).get(st0.v2Counter);
                backFlag = false;
                //p.print("\tBINDING: Backtracking to next prop in V2 in stage "+st0.istageNum);
                int V2size = ((ArrayList)hV2PredProp.get(st0.stagePred)).size();
                if((st0.v2Counter + 1) < V2size)
                {
                    BackTrack b = new BackTrack();
                    b.stageID=stageCounter;
                    b.v2Counter=st0.v2Counter+1;
                    backTrack.add(b);
                }
            }
            hBindings.put(stageCounter,st0);
        }
        ArrayList v2Pred = (ArrayList)hV2PredProp.get(st0.stagePred);
        //PrintBindingStatus(st1.stagePred,stageCounter,p11,p12);
        ReturnStructure r = st0.PropV1.bindPropAxiom(st0.PropV2,st0.BindingTillNow,new Hashtable(), sAxNum);
        //p.print("Props selected: "+p11.atom.getAtom()+" "+p12.atom.getAtom());
        if(r.possible == true)
        {
            st0.BindingTillNow.putAll(r.hMappings);
            hBindings.put(stageCounter, st0);
            stageCounter++;
            prevStageCounter= stageCounter-1;
            //p.print("\n"+p11.atom.getAtom()+" can be merged with "+p12.atom.getAtom());
        }
        else if(r.possible == false)
        {
            if(backTrack.isEmpty())
            { return(new Hashtable()); }
            else
            { backFlag = true; }
        }
    }
    //get all the v2 props that were selected
    ArrayList merged = new ArrayList();
    int size = hBindings.size();
    int isize =1;
    while(isize < size)
    {
        Stage val = (Stage)hBindings.get(isize);
        merged.add(val.PropV2);
        isize++;
    }
    Hashtable returnHash = new Hashtable();
    returnHash.put("props",merged);
    returnHash.put("maps",((Stage)hBindings.get(iTotalBindings)).BindingTillNow);
    return(returnHash);
}


/**
 * Checks whether 2 propositions can be bound together given the merge
 * constraints or bindings which were created by virtue of previous
 * propositions merges.
 *
 * @param p1   Proposition from the consequent of Axiom
 * @param p2   Proposition from the Scenario
 * @param previousBindings  Hashtable containing argumement bindings
 *          such as {x1=x2, x3=x4}
 *          The constraints for binding can be found SOMEWHERE!!
 * @return  if binding is possible,
 */
/*Hashtable bindProp(Prop p1,Prop p2,Hashtable previousBindings)
{
    Hashtable h = new Hashtable();
    if(p1.atom.args.size() == p2.atom.args.size())
    {
        int ctr =0;
        while(ctr < p1.atom.args.size())
        {
            if((p1.depth>=Main.depth)||(p2.depth>=Main.depth))
            {
            Hashtable hsh  = new Hashtable();
            hsh.put("possible", "false");
            return(hsh);
            }
            String v1Arg = (String)p1.atom.args.get(ctr);
            String v2Arg = (String)p2.atom.args.get(ctr);
            if((h.containsKey(v1Arg)) && (!((String)h.get(v1Arg)).equals(v2Arg)))
            {
                Hashtable hsh  = new Hashtable();
                hsh.put("possible", "false");
                return(hsh);
            }
            if(!h.containsKey(v1Arg) && !previousBindings.containsKey(v1Arg))
            { h.put(v1Arg,v2Arg); }
            if(previousBindings.containsKey(v1Arg) && !((String)previousBindings.get(v1Arg)).equals(v2Arg))
            {
                Hashtable hsh  = new Hashtable();
                hsh.put("possible", "false");
                return(hsh);
            }
            ctr++;
        }
    }
    else
    {
        Hashtable hsh  = new Hashtable();
        hsh.put("possible", "false");
        return(hsh);
    }
    Hashtable hsh  = new Hashtable();
    hsh.put("possible", "true");
    hsh.put("maps", h);

    return(hsh);
}*/

/**
 * Indexes the propositions by predicate name
 *
 * @param al1   List of propositions
 * @return  Hashtable with propositions indexed by predicate name
 */
Hashtable indexByPred(ArrayList al1)
{
    Hashtable h = new Hashtable();
    Iterator ir1 = al1.iterator();
    while(ir1.hasNext())
    {
        Prop p = (Prop)ir1.next();
        if(h.containsKey(p.atom.pred))
        {
            ArrayList al = (ArrayList)h.get(p.atom.pred);
            al.add(p);
            h.put(p.atom.pred, al);
        }
        else
        {
            ArrayList al = new ArrayList();
            al.add(p);
            h.put(p.atom.pred, al);
        }
    }
    return(h);
}
/** Finds the Props in the Interpt, which have the same predicate name as
 * the Props in the Axiom. It then sorts the predicates in increasing order,
 * starting with the predicate that has fewest Props in the Interpt, to the
 * largest number of Props. Sorting leads to convergence in a shorter time.
 * (MATHEMATICAL ANALYSIS REQUIRED)
 *
 * @return  Hashtable indexed by the stage counter, containing the value
 * stageProp
 */
Hashtable getPockets()
{
    Hashtable hcount = new Hashtable();
    Print p = new Print();
    //Arrange the predicates from lower number of duplicates to higher duplicates
    //If all occur just once, arrange them in any order
    //Finding the frequency counts of all the propositions
    Enumeration e = hV1PredProp.keys();
    while(e.hasMoreElements())
    {
        ArrayList al1 = (ArrayList)hV1PredProp.get((String)e.nextElement());
        String predName = (String)((Prop)al1.get(0)).atom.pred;
        if(hcount.containsKey(predName))
        {
           int count = (Integer)hcount.get(predName);
           count=count+al1.size();
           hcount.put(predName,count);
        }
        else
        {
            hcount.put(predName, al1.size());
        }
    }
    //Add all the props from v2 into pockets, which have same pred as v1
    e = hV2PredProp.keys();
    while(e.hasMoreElements())
    {
        ArrayList al1 = (ArrayList)hV2PredProp.get((String)e.nextElement());
        String predName = (String)((Prop)al1.get(0)).atom.pred;
        if(hcount.containsKey(predName))
        {
           int count = (Integer)hcount.get(predName);
           count=count+al1.size();
           hcount.put(predName,count);
        }
        else
        {
            //If it does not already exist, do not add it. We want only
            //preds which occur in v1 and v2
        }
    }

    //currently it is pred-val array. Invert it to make it val - pred
    Hashtable hPockets = new Hashtable();
    int i=0;
    Enumeration en1 = hcount.keys();
    while(en1.hasMoreElements())
    {
        String key1 = (String)en1.nextElement();
        int val1 = (Integer)hcount.get(key1);
        if(hPockets.containsKey(val1))
        {
            ArrayList alx = (ArrayList)hPockets.get(val1);
            alx.add(key1);
            hPockets.put(val1, alx);
        }
        else
        {
                ArrayList alx = new ArrayList();
                alx.add(key1);
                hPockets.put(val1,alx);
        }
    }

    int stagectr=1;
    hStagePred = new Hashtable();
    Integer[] keys = (Integer[]) hPockets.keySet().toArray(new Integer[0]);
    /*we are sorting v1, so that we can start binding with the pred
    * occuring least number of times. The order of the binding is only
    * dependent on the frequency of props in the first list.*/
    Arrays.sort(keys);
    /*Assign stage numbers to each of the props in V1*/
    for(Integer key : keys)
    {
        ArrayList al1 = (ArrayList)hPockets.get(key);
        Iterator i1 = al1.iterator();
        while(i1.hasNext())
        {
            String pred = (String)i1.next();
            ArrayList alMisc = (ArrayList)hV1PredProp.get(pred);
            Iterator itAlMisc = alMisc.iterator();
            while(itAlMisc.hasNext())
            {
                Prop p1 = (Prop)itAlMisc.next();
                hStagePred.put(stagectr,p1);
                stagectr++;
            }

        }
    }
    return(hStagePred);
}
/**
 * Prints the current binding stage, current predicate and the selected
 * propositions
 *
 * @param pred  Predicate name being bound
 * @param stageCounter  The current stage being bound. If current stage =
 *          total propositions in consequent of axiom, all props are bound
 * @param p1    Proposition from consequent of axiom
 * @param p2    Proposition from scenario
 */
void PrintBindingStatus(String pred,int stageCounter,Prop p1, Prop p2)
{
    Print p = new Print();
    //p.print("\nTotal Bindings Possible = "+iTotalBindings);
    p.print(Main.location, "Current binding phase = "+stageCounter, Main.bwOut);
    p.print(Main.location, "Current binding predicate = "+pred, Main.bwOut);
    p.print(Main.location, "Selected Props: V1: "+p1.atom.getAtom()+" v2: "+p2.atom.getAtom(), Main.bwOut);
    p.print(Main.location, "------------------------------", Main.bwOut);
}
/**
 * Creates a new instance of the Binding class
 */
public Binding()
{
    hV1PredProp = new Hashtable();
    hV2PredProp = new Hashtable();
    hStagePred = new Hashtable();
    hBindings = new Hashtable();
    backTrack = new ArrayList();
}  
}
