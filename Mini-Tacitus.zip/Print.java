package minitacitus;
import java.util.*;
import java.io.*;
/**
 * All the print functions are taken care of in this class
 * 
 * @author Rutu Mulkar-Mehta
 */
public class Print 
{
    void print(String location, String comment, BufferedWriter b)
    {
        if(location.equals("stdout"))
        {
            System.out.println(comment);
        }
        else if(location.equals("suppress"))
        {
            /* All comments are suppressed */
        }
        else if(location.equals("file"))
        {
            /*the required output needs to be printed to a file. Use the bufferedWriter*/
            try
            {
                b.write(comment + "\n");
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
        }
     
    }
    /**
     * 
     * @param h
     */
    void printHashIntegerArrayList(Hashtable h)
    {
        Enumeration e = h.keys();
        while(e.hasMoreElements())
        {
            int k1 = (Integer)e.nextElement();
            ArrayList v1 = (ArrayList)h.get(k1);
            System.out.print(k1);
            Iterator ial = v1.iterator();
            while(ial.hasNext())
            {
                System.out.print("\t"+(String)ial.next());
            }
            System.out.println();
        }
    }
    /**
     * Prints the correct argument required to run the Engine, when an incorrect
     * set of arguments are entered, or no arguments are entered
     */
    void Usage()
    {
        System.out.println("java -jar Tacitus.jar <Axiom File> <Scenario File> <Output Folder> <Depth>");
        System.out.println("Mini-TACITUS Version 0.0.4\n");
        System.out.println("<Axiom File> : Input Axioms file name");
        System.out.println("<Scenario File> : Input Scenario file name");
        System.out.println("<Output Folder> : Folder name that must contain the output files");
        System.out.println("<Depth> : Integer value for maximum backchaining possible per proposition");
    }
    /**
     * Prints a Hashtable where the key is a String, and the value is an array
     * 
     * @param h Hashtable of the structure, String = ArrayList
     */
    void printHashStringArrayList(Hashtable h)
    {
        Enumeration e = h.keys();
        while(e.hasMoreElements())
        {
            String k1 = (String)e.nextElement();
            ArrayList v1 = (ArrayList)h.get(k1);
            System.out.print(k1);
            Iterator ial = v1.iterator();
            while(ial.hasNext())
            {
                System.out.print("\t"+(String)ial.next());
            }
            System.out.println();
        }
    }
    /**
     * Prints a Hashtable where the key is a String and the value is an Array of
     * Props
     * 
     * @param h Hashtable where the key is a String and the value is an Array of
     * Props
     */
    void printHashStringPropArrayList(Hashtable h)
    {
        Enumeration e = h.keys();
        while(e.hasMoreElements())
        {
            String k1 = (String)e.nextElement();
            ArrayList v1 = (ArrayList)h.get(k1);
            System.out.print(k1);
            Iterator ial = v1.iterator();
            while(ial.hasNext())
            {
                System.out.print("\t"+((Prop)ial.next()).getProp());
            }
            System.out.println();
        }
    }
    /**
     * Prints a Hashtable where the key is a String and the value is an Integer
     * 
     * @param h Hashtable where the key is a string and the value is an Integer
     */
    void printHashStringInt(Hashtable h)
    {
        Enumeration e = h.keys();
        while(e.hasMoreElements())
        {
           String k1 = (String)e.nextElement();
           int v1 = (Integer)h.get(k1);
           //System.out.println(k1+"  "+v1);
        }
    }
    /**
     * Prints a Hashtable where the key is a String and the value is also a 
     * String
     * 
     * @param h Hashtable where the key is a String and the value is also a 
     * String
     */
    void printHashStringString(Hashtable h)
    {
        Enumeration e = h.keys();
        while(e.hasMoreElements())
        {
           String k1 = (String)e.nextElement();
           String v1 = (String)h.get(k1);
           //System.out.println(k1+"  "+v1);
        }
    }
    /** Prints a String
     * @param s A simple String */
    void printString(String s)
    {
        System.out.println(s);
    }
    /** Prints 2 strings
     * @param s1    String 1
     * @param s2    String 2 */
    void printKeyVal(String s1,String s2)
    {
        System.out.println(s1+"   "+s2);
    }
    /**
     * Prints an ArrayList which contains Props as individual elements to
     * STDOUT
     * 
     * @param al1   ArrayList which contains Props as individual elements
     */
    void printPropArrayList(ArrayList al1)
    {
        Iterator i1 = al1.iterator();
        while(i1.hasNext())
        {
            Prop p = (Prop)i1.next();
            System.out.println(p.atom.getAtom()+" "+p.depth);
        }
    }
    /**
     * Prints an ArrayList which contains Props as individual elements to a 
     * file in HTML format
     * 
     * @param al1   ArrayList which contains Props as individual elements
     * @param o Filename where the ArrayList is to be printed
     */
    void printPropArrayList(ArrayList al1,BufferedWriter o)
    {
        try
        {
            if(al1.size() > 1)
            {
                Iterator i1 = al1.iterator();
                while(i1.hasNext())
                {
                    Prop p = (Prop)i1.next();
                    if(!p.atom.pred.equals(""))
                    {
                        if(p.depth >= Main.depth)
                        { o.write("<b>"+p.atom.getAtom()+ ":"+p.depth+":"+p.cost+" , </b>"); }
                        else
                        { o.write(p.atom.getAtom()+ ":"+p.depth+":"+p.cost+" , "); }
                    }
                }
            }
            else
            {
                Prop p = (Prop)al1.get(0);
                if(p.atom.pred.equals(""))
                {
                    o.write("none");
                }
                else
                {
                    if(p.depth >= Main.depth)
                    { o.write("<b>"+p.atom.getAtom()+ ":"+p.depth+":"+p.cost+" , </b>"); }
                    else
                    { o.write(p.atom.getAtom()+ ":"+p.depth+":"+p.cost+" , "); }
                }
            }
        }
        catch(Exception e)
        { e.printStackTrace(); }
    }
    /**
     * Prints an ArrayList which contains Props as individual elements to a 
     * file in text format
     * 
     * @param al1   ArrayList which contains Props as individual elements
     * @param o Output file name
     */
    void printPropArrayListText(ArrayList al1,BufferedWriter o)
    {
        try
        {
            if(al1.size() > 1)
            {
                Iterator i1 = al1.iterator();
                while(i1.hasNext())
                {
                    Prop p = (Prop)i1.next();
                    if(!p.atom.pred.equals(""))
                    { o.write(p.getPropDetails()+"\n"); }
                }
            }
            else
            {
                Prop p = (Prop)al1.get(0);
                if(p.atom.pred.equals(""))
                { o.write("none"); }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    
    /**
     * Selects the lowest cost Interpt that is shallowest in the tree
     * of Interpts and prints it to a plain text file
     * 
     * @param fileName  Filename where the Interpt must be printed
     */
    void printBestInterpt(String fileName)
    {
        try
        {
            BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
            int max = Main.hInterpt.size();
            int i=0;
            String sel = new String();
            int cost =99999;
            Vector v = new Vector(Main.hInterpt.keySet());
            Collections.sort(v);
            Iterator it = v.iterator();
            while(it.hasNext())
            {
                String key = (String)it.next();
                Interpt iInt = (Interpt)Main.hInterpt.get(key);
                if(iInt.icost < cost)
                {
                    cost = iInt.icost;
                    sel = key;
                }
                i++;
            }
            Interpt interpt = (Interpt)Main.hInterpt.get(sel);
            printPropArrayListText(interpt.alProps,output);
            output.write("\n-----\nNo Merge:" + interpt.hNoMerge);
            output.write("\n-----\nCost: "+interpt.icost);
            output.write("\nID: "+interpt.iInterptNum);
            output.close();
        }
        catch(Exception e)
        { e.printStackTrace(); }
    }
    /**
     * Prints all in Interpts currently in the set of Interpretations and prints
     * it to an HTML file
     * 
     * @param fileName  HTML filename where the Interpts need to be printed
     */
    
    void printAllInterptsHTML(String fileName)
    {
        try
        {
            BufferedWriter output = new BufferedWriter(new FileWriter(fileName));
            output.write("<html><title>Output</title><head></head>");
            output.write("<body>");
            output.write("<table cellspacing=2 cellpadding=2 border=1 width=\"800\" align=\"center\">");
            output.write("<tr>");
            output.write("<td width=20><b>No.</b></td>");
            output.write("<td><b>Props</b></td>");
            output.write("<td><b>Backchained Props</b></td>");
            output.write("<td width=20><b>Cost</b></td>");
            output.write("<td><b>Parent</b></td>");
            output.write("<td><b>Axiom Number</b></td>");
            output.write("<td><b>Duplicate</b></td>");
            //output.write("<td><b>Fingerprint</b></td>");
            //output.write("<td><b>NoMerge</b></td>");
            //output.write("<td><b>Constants</b></td>");
            output.write("</tr>");
            int i=0;
            Vector v1 = new Vector(Main.hInterpt.keySet());
            Vector v = Sorter.sort(v1);
            Iterator it = v.iterator();
            while(it.hasNext())
            {
                Interpt iInt = (Interpt)Main.hInterpt.get((String)it.next());
                //if(!iInt.bDuplicate)
                {
                    output.write("<tr>");
                    printInterptHTML(iInt,output);
                    output.write("</tr>");
                    i++;
                }
            }
            output.write("</table>");
            output.write("</body>");
            output.write("</html>");
            output.close();
        }
        catch(Exception e)
        { e.printStackTrace(); }
    }
    
    /**
     * Prints a single Interpt from the set of Interpts, and writes it to an 
     * HTML file
     * 
     * @param interpt   Interpt object that needs to be printed
     * @param o Output filename where the Interpt must be printed
     */
    void printInterptHTML(Interpt interpt,BufferedWriter o)
    {
        try
        {
            o.write("<td valign=\"top\"> <a name=\""+interpt.iInterptNum+"\">"+interpt.iInterptNum+"</td>");
            o.write("<td> ");
            printPropArrayList(interpt.alProps,o);
            o.write("</td>");
            o.write("<td> ");
            printPropArrayList(interpt.alCurrProps,o);
            o.write("</td>");
            o.write("<td> "+interpt.icost+"</td>");
            o.write("<td> <a href=\"#"+interpt.iParentID+"\">"+interpt.iParentID+"</a></td>");
            o.write("<td> "+interpt.sAxiomUsed+"</td>");
            o.write("<td> "+interpt.bDuplicate+"</td>");
            //o.write("<td>"+interpt.hFingerPrint.hashCode()+"</td>");
            //o.write("<td>"+interpt.hNoMerge+"</td>");
            //o.write("<td>"+interpt.hConstants+"</td>");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    /**
     * Prints a single Interpt on to STDOUT
     * 
     * @param interpt   Interpt that needs to be printed
     */
    void printInterpt(Interpt interpt)
    {
        /*System.out.println(interpt.iInterptNum);
        System.out.println(interpt.icost);
        System.out.println(interpt.iParentID);
        printPropArrayList(interpt.alCurrProps);*/
        printPropArrayList(interpt.alProps);        
    }
    
}
