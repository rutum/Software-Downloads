/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.Hashtable;
/**
 *Structure that contains 2 props and the hash mappings between them
 * @author Rutu Mulkar-Mehta
 */
public class PropMap
{
    /** First Prop */
    Prop p1;
    /** Second Prop */
    Prop p2;
    /** Argument mapping between both the Props */
    Hashtable hMaps;
    /**
     * Prints the PropMap structure
     * @return String equivalent of the PropMap structure
     */
    String printPropMap()
    {
        String retVal = p1.getProp()+" "+p2.getProp();
        return(retVal);
    }
    /**
     * Creates a new instance of the PropMap
     */
    public PropMap()
    {
        p1 = new Prop();
        p2 = new Prop();
        hMaps = new Hashtable();
    }
}
