/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
/**
 * This class has functions dealing with the smallest data structure - an Atom.
 * An atom consists of a Predicate name and arguments. The syntax of an atom is:
 * predicate(arg1,arg2,arg3,...). In most cases, the predicate name is conjoined 
 * with the part of speech of the word. e.g. The logical form for "happy man"
 * is : happy-adj'(e2,x1) & man-nn'(e1,x1). Here -adj, and -nn represent the 
 * adjective happy and the noun man. This is an optional field, and is sometimes
 * ommitted with the part of speech of the word is not mentioned in the dictionary,
 * or is incorrectly parsed by the parse.
 * 
 * @author Rutu Mulkar-Mehta
 */
public class Atom 
{
    /** Stores the predicate name of the Atom */
    String pred;
    /** Stores the list of arguments of the Atom */
    ArrayList args;
    /**
     * Update the arguments of the current Proposition, based on the Hashtable
     * of argument mappings provided. This function is used when an Axiom is 
     * applied to an Interpt. When the Props in the RHS of an Axiom are 
     * merged/bound with the Props in the Scenario, the arguments in the RHS of 
     * the Axiom are mapped to the arguments of the Props in the Scenario/Interpt.
     * This mapping of arguments are mentioned in the Hashtable passed to this 
     * function. <br>
     * These arguments are used to apply to the Props on the LHS of the Axiom. 
     * If the arguments on the LHS are new, and have not occured previously in 
     * the RHS/consequent, a new argument value is created by prepending the 
     * argument with a "ptr" and a unique number
     * 
     * @param h Hashtable containing the argument mappings, based on the 
     * bound propositions
     */
    Hashtable updateArgumentsAxiom(Hashtable h, Hashtable hAx)
    {
        int i =0;
        while(i<this.args.size())
        {
            String arg = (String)(String)this.args.get(i);
            if(h.containsKey(arg))
            {
                this.args.remove(i);
                this.args.add(i,(String)h.get(arg));
            }
            else
            {
               if(hAx.containsKey(arg))
               {
                this.args.remove(i);
                this.args.add(i,(String)hAx.get(arg));
               }
               else
               {
                String arg1 = Interpt.ax+"ptr";
                Interpt.ax++;
                hAx.put(arg, arg1);
                arg = arg1;
                this.args.remove(i);
                this.args.add(i,arg);
               }
            }
            i++;
        }
        return(hAx);
    }
    /**
     * Determines whether 2 atoms can be bound to each other given the constraints
     * of the previous already existing bindings, set of arguments that cannot be
     * merged (hNM), and a set of Constants. Primarily used for binding the
     * props of an Axiom to the Props of an Interpt, when an Axiom is applied on
     * an Interpt.
     * 
     * @param a2
     * @param previousBindings
     * @param hNM
     * @return
     */
    ReturnStructure bindAtom(Atom a2, Hashtable previousBindings, Hashtable hNM)
    {
        Hashtable currentBindings = new Hashtable();
        if(this.args.size() == a2.args.size())
        {
            int ctr =0;
            while(ctr < this.args.size())
            {
                String v1Arg = (String)this.args.get(ctr);
                String v2Arg = (String)a2.args.get(ctr);
                /* If a binding already exists in previous binding or current bindings
                 * or if a bind is not possible because of the no Merge conditions
                 * return a false */                
                if((currentBindings.containsKey(v1Arg)) && (!((String)currentBindings.get(v1Arg)).equals(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }        
                else if((previousBindings.containsKey(v1Arg) && !((String)previousBindings.get(v1Arg)).equals(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }
                else if((hNM.containsKey(v1Arg)) && (((Hashtable)hNM.get(v1Arg)).containsKey(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }
                else if((!currentBindings.containsKey(v1Arg) && !previousBindings.containsKey(v1Arg))||
                        ((hNM.containsKey(v1Arg)) && (!((Hashtable)hNM.get(v1Arg)).containsKey(v2Arg))))
                { 
                    currentBindings.put(v1Arg,v2Arg);
                    //currentBindings.put(v2Arg,v1Arg);
                }
                ctr++;
            }
        }
        else
        {
            ReturnStructure r = new ReturnStructure();
            r.possible=false;
            return(r);
        }
        ReturnStructure r = new ReturnStructure();
        r.possible=true;
        r.hMappings.putAll(currentBindings);
        return(r);
    }

    /**
     * Checks whether 2 atoms are mergeable based on the noMerge conditions
     * and the constant set provided by the caller function
     *
     * @param a2    Second atom to be merged with
     * @param hNM   Set of noMerge conditions
     * @param hCons Set of constants provided
     * @return  ReturnStructure
     */
    ReturnStructure mergeAtom(Atom a2, Hashtable hNM, Hashtable hCons)
    {
        Hashtable currentBindings = new Hashtable();
        if((this.args.size() == a2.args.size())&&(!this.pred.equals("PARTOF'"))&&(!this.pred.equals("CAUSE'")))
        {
            int ctr =0;
            while(ctr < this.args.size())
            {
                String v1Arg = (String)this.args.get(ctr);
                String v2Arg = (String)a2.args.get(ctr);
                /* If a binding already exists in previous binding or current bindings
                 * or if a bind is not possible because of the no Merge conditions
                 * return a false */
                if((currentBindings.containsKey(v1Arg)) && (!((String)currentBindings.get(v1Arg)).equals(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }
                else if((hNM.containsKey(v1Arg)) && (((Hashtable)hNM.get(v1Arg)).containsKey(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }
                else if(hCons.containsKey(v1Arg) && (hCons.containsKey(v2Arg)) && (!v1Arg.equals(v2Arg)))
                {
                    ReturnStructure r  = new ReturnStructure();
                    r.possible=false;
                    return(r);
                }
                else if((!currentBindings.containsKey(v1Arg)) && (!currentBindings.containsKey(v2Arg)))                     
                {
                    if(((hNM.containsKey(v1Arg)) && (!((Hashtable)hNM.get(v1Arg)).containsKey(v2Arg))) ||
                            (!hNM.containsKey(v1Arg)))
                    {
                        /* The current arguments are not in any bindings, and they
                        * do not have a no merge condition with each other */
                        /*if one of them is a constant, map the other arg to it
                        * else random mapping*/
                        if((hCons.containsKey(v1Arg))&&(!hCons.containsKey(v2Arg)))
                        {
                            currentBindings.put(v2Arg,v1Arg);
                        }
                        else if((!hCons.containsKey(v1Arg))&&(hCons.containsKey(v2Arg)))
                        {
                            currentBindings.put(v1Arg,v2Arg);
                        }
                        else
                        {
                            currentBindings.put(v1Arg,v2Arg);
                        }
                        //currentBindings.put(v2Arg,v1Arg);
                    }
                }
                ctr++;
            }
        }
        else
        {
            ReturnStructure r = new ReturnStructure();
            r.possible=false;
            return(r);
        }
        ReturnStructure r = new ReturnStructure();
        r.possible=true;
        r.hMappings.putAll(currentBindings);
        return(r);
    }

    /**
     * Updates the arguments of Props in an Interpretation, based on the
     * hashtable of merged arguments provided
     *
     * @param h Hash of mapped arguments
     */
    void updateArgumentsInterpt(Hashtable h)
    {
        int i =0;
        while(i<this.args.size())
        {
            String arg = (String)this.args.get(i);
            if(h.containsKey(arg))
            {
                this.args.remove(i);                
                this.args.add(i,(String)h.get(arg));
            }
            i++;
        }
    }
    /**
     * Converts a string into the respective elements of an Atom. The input 
     * String format of the Atom should be : pred(arg1,arg2,....)
     * 
     * @param s String representation of the Atom. Syntax of an atom is:
     * pred(arg1,arg2,....)
     * @return  True if the syntax of the Atom is correct, False if the syntax
     * of the Atom is incorrect.
     */
    boolean setAtom(String s)
    {
        StringTokenizer st = new StringTokenizer(s,"(");
        if(st.countTokens()==2)
        {
            this.pred=(String)st.nextElement();
            StringTokenizer stArgplus = new StringTokenizer((String)st.nextElement(),")");
            StringTokenizer stArg = new StringTokenizer((String)stArgplus.nextElement(),",");
            while(stArg.hasMoreElements())
            {
                String nextArg = (String)stArg.nextElement();
                this.args.add(nextArg);
            }
            return(true);
        }
        else
        {
            System.err.println("ATOM: Illegal Syntax in atom: Incorrect Token numbers. "+s);
            return(false);
        }
    }
    
    /**
     * Accesses the data structure of the Atom, and returns the string
     * representation for it
     * 
     * @return String representation of the Atom. They syntax is - 
     * predname(arg1,arg2,...)
     */
            
    String getAtom()
    {
        String prop1 = new String();
        prop1 = this.pred+"(";
        int size = this.args.size();
        for(int i=0;i<size;i++)
        {
            prop1=prop1+this.args.get(i);
            if(i!=size-1)
            {
                    prop1=prop1+",";
            }
        }
        prop1 = prop1+")";
        return(prop1);
    }
    
    /**
     * Copies the value of the given atom (passed to the function) to the 
     * current atom
     * 
     * @param a Instance of the Atom whose value needs to be copied
     */
    
    void copy(Atom a)
    {
        this.pred=a.pred;
        this.args.addAll(a.args);
    }
    
    /**
     * Creates a new instance of the Atom
     */
    
    public Atom()
    {
        pred = new String();
        args = new ArrayList();
    }

}
