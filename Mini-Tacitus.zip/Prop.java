/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
import java.util.regex.*;
/**
 * A Prop is a short form of Proposition (similar to propositions in First Order
 * Logic). A Prop contains an Atom, a String ID, Integer Depth and Integer Cost.
 * <br><br>
 * The Atom class contains the smallest knowledge storing facility. However, 
 * for a detailed reasoning, more information needs to be attached to the Atom.
 * A Prop (proposition) holds this extra information- Unique ID, Cost and Max
 * depth of the Atom. 
 * <br><br>
 * All abductive inferences are performed on Props as opposed to Atoms. This is
 * because Props have additional functionality of:
 * <ul>
 *      <li> A cost factor assigned to them.
 *      <li> A depth assigned to them
 * </ul>
 *  
 * @author Rutu Mulkar-Mehta
 */
public class Prop 
{
    /** Atom which makes up the Prop */
    Atom atom;
    /** Unique ID of the Prop within a specific Interpt */
    String id;
    /** Cost of the Prop */    
    int cost;
    /** Number of times the Prop is backchained on. A Prop cannot be backchained 
     * on more times than the maximum depth. */
    int depth;
    /** List of Axioms already used on this Prop */
    Hashtable hAxioms;
    
    /**
     * Checks whether 2 propositions can be bound together given the merge 
     * constraints or bindings which were created by virtue of previous 
     * propositions merges.
     * @param p2 Proposition from the Scenario
     * @param previousBindings  previousBindings  Hashtable containing argumement bindings
     *          such as {x1=x2, x3=x4}
     *          The constraints for binding: 2 arguments located in the same 
     *          prop cannot bind with each other. 2 Nouns with different names
     *          cannot bind with each other.
     * @param hNM   Set of arguments that cannot be merged with each other
     * @return  Hashtable with the keys - Possible = true, maps = argument bindings
     *          if the mapping is true<br>
     *          Hashtable with the key - possible = false, if the mapping is false
     */
    ReturnStructure bindProp(Prop p2,Hashtable previousBindings,Hashtable hNM)
    {
        /*if((this.depth>=Main.depth)||(p2.depth>=Main.depth)) //or the prop already contains
            //the axiom number in its axiom hash
        {
            Hashtable hsh  = new Hashtable();
            ReturnStructure r = new ReturnStructure();
            r.possible=false;
            return(r);
        }
        else*/
        {
            ReturnStructure r = this.atom.bindAtom(p2.atom, previousBindings, hNM);
            return(r);
        }
    }

    ReturnStructure bindPropAxiom(Prop p2,Hashtable previousBindings,Hashtable hNM, String sAxNum)
    {
        if((this.depth>=Main.depth)||(p2.depth>=Main.depth)||(p2.hAxioms.containsKey(sAxNum)))
            //or the prop already contains
            //the axiom number in its axiom hash
        {
            Hashtable hsh  = new Hashtable();
            ReturnStructure r = new ReturnStructure();
            r.possible=false;
            return(r);
        }
        else
        {
            ReturnStructure r = this.atom.bindAtom(p2.atom, previousBindings, hNM);
            return(r);
        }
    }

    /**
     * Returns the String representation of the Prop in the format: 
     * pred(arg1,arg2,....) ID cost depth
     * 
     * @return  String value of the Prop
     */
    String getProp()
    {
        String prop1 = new String();
        prop1 = this.atom.getAtom();
        if(prop1.equals(""))
        { return("none"); }
        prop1 = prop1 + " "+this.id+" "+this.cost;
        return(prop1);
    }

    String getPropDetails()
    {
        String prop1 = new String();
        prop1 = this.atom.getAtom();
        if(prop1.equals(""))
        { return("none"); }
        prop1 = prop1 + ":"+this.id+":"+this.cost+":"+this.depth+":"+this.hAxioms;
        return(prop1);
    }
    /** * Copies the value of given Prop p, to the current Prop
     * 
     * @param p The Prop whose value needs to be copied  */    
    void copy(Prop p)
    {
        this.cost=p.cost;
        this.depth= p.depth;
        this.id=p.id;
        this.atom.copy(p.atom);
        this.hAxioms.putAll(p.hAxioms);
    }
    
    /** Finds the cost of a Prop in the LHS of the Axiom, based on the costs
     * on the RHS of the Axiom. Currently, the cost of the Prop on the LHS is 
     * a fraction of the sum of the cost of the Props on the RHS
     * 
     * @param alRHS ArrayList of Props on the RHS of the Axiom */
    void costPropLHS(ArrayList alRHS)
    {
        /* CURRENT ALGORITHM : cost of LHS is a fraction of the sum of RHS*/
        /*find the total cost of RHS*/
        int i=0,newcost=0;
        while(i<alRHS.size())
        {
            Prop ptmp = (Prop)alRHS.get(i);
            newcost = newcost + ptmp.cost;
            i++;
        }
        this.cost = this.cost * newcost/100;
    }
    
    /** Sets the value of a Prop when the String format of the Prop is Provided.
     * The syntax of a Prop in a Scenario is : predicate(arg1,arg2)_id:cost
     * 
     * @param s The string representation of the Prop
     * @return  True if there is no syntax error, False otherwise */
    boolean setProp(String s)
    {
        this.atom=new Atom();
        /*remove spaces from the string*/
        s=s.trim();
        StringTokenizer st = new StringTokenizer(s,":");
        if(st.countTokens()==2)
        {
            String atm = (String)st.nextElement();
            //StringTokenizer st2 = new StringTokenizer(propnid,"_");
            //String atm = (String)st2.nextElement();
            //if(st2.countTokens() == 1)
            //{
            //    this.id = (String)st2.nextElement();
            //}
            //else
            //{
            //    int tmpID = Main.iMaxID;
            //    Main.iMaxID ++;
            //    String sid = new String(Integer.toString(tmpID));
                //p.print("Prop: No ID provided for "+this.atom.pred+", automatically assigning "+sid);
                //automatically assign ID for the proposition
            //    this.id=sid;
            //}
            boolean b = this.atom.setAtom(atm);
            if(!b) { return(false); }
            try
            {  this.cost = Integer.parseInt((String)st.nextElement());  }
            catch(NumberFormatException e)
            { 
                System.err.println("PROP:Illegal number encountered. Please check for spaces: "+s);
                return(false); 
            }
            this.depth=0;
            return(true);
        }
        else
        {
            Print p = new Print();
            p.print(Main.location, "\n\tPROP: Illegal Format of Prop: Incorrect token numbers "+s, Main.bwOut);
            return(false);
        }
    }
    boolean setPropInterpt(String s)
    {
        this.atom=new Atom();
        /*remove spaces from the string*/
        s=s.trim();
        StringTokenizer st = new StringTokenizer(s,":");
        if(st.countTokens()==5)
        {
            String atm = (String)st.nextElement();
            this.id = (String)st.nextElement();
            try { this.cost = Integer.parseInt((String)st.nextElement()); }
            catch(NumberFormatException e)
            { System.err.println("PROP:Illegal number encountered (Cost) : "+s); return(false); }
            try{ this.depth = Integer.parseInt((String)st.nextElement()); }
            catch(NumberFormatException e)
            { System.err.println("PROP:Illegal number encountered (Depth) : "+s); return(false); }
            String hashAx = (String)st.nextElement();
            hashAx = hashAx.substring(1,hashAx.length()-1);
            Pattern axHash = Pattern.compile(",");
            String[] unit = axHash.split(hashAx);
            for(int i=0;i<unit.length;i++)
            {
                if(unit[i].contains("="))
                {
                    Pattern ax = Pattern.compile("=");
                    String[] sAxiom = ax.split(unit[i]);
                    this.hAxioms.put(sAxiom[0], sAxiom[1]);
                }
            }
            boolean b = this.atom.setAtom(atm);
            if(!b) { return(false); }            
            return(true);
        }
        else
        {
            System.err.println("\n\tPROP: Illegal Format of Prop: Incorrect token numbers "+s);
            return(false);
        }
    }
    /** Creates a new Prop */    
    public Prop()
    {
        atom=new Atom();
        id = "";
        depth = 0;
        cost=0;
        hAxioms = new Hashtable();
    }
}
