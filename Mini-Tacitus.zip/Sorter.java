/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package minitacitus;
import java.util.*;
/**
 * Numerical String sorter
 *@author Mario Gianota <mario.gianota@bookkeeperseye.com>
 */
public class Sorter {

    /**
     * Sorts a Vector that contains strings into ascending order taking into
     * account that Strings which begin with digits should appear in the
     * sorted output before those with alphabetical characters.
     *
     * The method accepts a Vector as a parameter, and returns another Vector with
     * the same elements, except now in a sorted order.  Rather than employ two
     * different methods for both cases above.  The method employs a "smart" algorithm that
     * sorts NUMERICALLY and then ALPHABETICALLY on the same vector, as a bonus.
     *
     *@param v A Vector of String elements
     *@return A new Vector in sorted order
     */
    public static Vector sort(Vector v) {
        // Clone the input Vector and sort its
        // String elements into alphabetical order
        Vector copy = (Vector)v.clone();
        Collections.sort(copy);

        // Split the sorted copy into two Vectors one containing
        // numerical Strings and the other containing alphabetical
        // Strings
        Vector numeric = new Vector();
        Vector alpha = new Vector();
        Enumeration e = copy.elements();
        while( e.hasMoreElements() ) {
            String value = (String)e.nextElement();
            if( Character.isDigit(value.charAt(0)) )
                numeric.addElement(value);
            else
                alpha.addElement(value);
        }

        // An anonymous String comparator that performs
        // a comparison of two Strings. It relies on the
        // fact that the Strings have already been lexicographically
        // sorted --which is done above.
        Comparator c = new Comparator() {
            public int compare(Object o1, Object o2) {

                // Convert both objects to String
                String s1 = o1.toString();
                String s2 = o2.toString();

                // If o1 is digit(s) and o2 is digit(s)
                String d1 = getDigits(s1);
                String d2 = getDigits(s2);
                int i1 = Integer.parseInt(d1);
                int i2 = Integer.parseInt(d2);
                if( i1 == i2 ) return 0;
                else if( i1 > i2 ) return 1;
                else return -1;

             }
            /**
             * Returns the String of digits prepended to a String.
             * If the String has no digits prepended then "0" is
             * returned.
             *@return String
             */
            private final String getDigits(String s) {
                if( ! Character.isDigit(s.charAt(0)) )
                    return "0";
                StringBuffer sb = new StringBuffer();

                int start=0;
                // check for sign
                if( s.charAt(0) == '-' ) {
                    start = 1;
                }
                // buffer digits
                for(int i=start; i<s.length(); i++) {
                    if(Character.isDigit(s.charAt(i))) {
                        sb.append(s.charAt(i));
                    } else {
                        i = s.length();
                    }
                }
                return sb.toString();
            }
        };
        // Now sort the numerical list
        Collections.sort(numeric,c);

        // Clear out the copy, and add the numerical list and
        // then the alpha list.
        copy.removeAllElements();
        Enumeration e2 = numeric.elements();
        Enumeration e3 = alpha.elements();
        while( e2.hasMoreElements() )
            copy.addElement(e2.nextElement());
        while( e3.hasMoreElements() )
            copy.addElement(e3.nextElement());

        return copy;
    }
}